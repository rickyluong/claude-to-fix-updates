/* Claude To Fix — page UI (bar, pick mode, note box, fix list panel).
 * Everything lives in a closed Shadow DOM so the site can't style it and it can't style the site.
 * Never reads form values or passwords. */
(() => {
  if (window.__claudeToFixLoaded) return;
  window.__claudeToFixLoaded = true;

  const api = globalThis.browser && globalThis.browser.runtime ? globalThis.browser : globalThis.chrome;
  const send = (msg) => api.runtime.sendMessage(msg).catch(() => null);
  const TYPES = ['Bug', 'Layout', 'Style', 'Text', 'Idea'];
  const TYPE_ICON = { Bug: '🐞', Layout: '📐', Style: '🎨', Text: '✏️', Idea: '💡' };

  let settings = { position: 'top-center', defaultType: 'Style', blurForms: true };
  let visible = false;
  let userTouched = false;
  let picking = false;
  let busy = false;

  /* ---------------- shadow host ---------------- */

  const host = document.createElement('claude-to-fix');
  host.setAttribute('style', 'all: initial !important; position: fixed !important; inset: 0 !important; width: 0 !important; height: 0 !important; z-index: 2147483647 !important; pointer-events: none !important; display: block !important;');
  const root = host.attachShadow({ mode: 'closed' });

  root.innerHTML = `
<style>
  :host { all: initial; }
  * { box-sizing: border-box; font-family: "Segoe UI", system-ui, -apple-system, Roboto, Arial, sans-serif; }
  .hidden { display: none !important; }

  /* --- bar --- */
  .bar {
    position: fixed; top: 12px; left: 50%; transform: translateX(-50%);
    display: flex; align-items: stretch; pointer-events: auto;
    background: #ff8a7a; border: 2px solid #e5503f; border-radius: 999px;
    box-shadow: 0 6px 24px rgba(120, 20, 10, .35); overflow: hidden; user-select: none;
    color: #3a0d07; font-size: 15px; font-weight: 700; line-height: 1;
  }
  .bar.pos-top-right { left: auto; right: 16px; transform: none; }
  .bar.pos-bottom-right { top: auto; bottom: 16px; left: auto; right: 16px; transform: none; }
  .bar.custom { transform: none; right: auto; bottom: auto; }
  .grip { width: 26px; display: flex; align-items: center; justify-content: center; cursor: grab; color: #8f2a1d; font-size: 16px; letter-spacing: -2px; }
  .grip:active { cursor: grabbing; }
  .bar button {
    all: unset; cursor: pointer; padding: 11px 18px; display: flex; align-items: center; gap: 8px;
    color: #3a0d07; font-size: 15px; font-weight: 700; white-space: nowrap;
  }
  .bar button + button { border-left: 2px solid #e5503f; }
  .bar button:hover { background: #ffb0a4; }
  .bar button.on { background: #e5503f; color: #fff; }
  .count {
    min-width: 22px; height: 22px; padding: 0 6px; border-radius: 999px; background: #fff; color: #c2311f;
    display: inline-flex; align-items: center; justify-content: center; font-size: 13px; font-weight: 800;
  }

  /* --- pick mode --- */
  .shield { position: fixed; inset: 0; pointer-events: auto; cursor: crosshair; background: transparent; }
  .hl {
    position: fixed; pointer-events: none; border: 2px solid #ff2d2d; background: rgba(255, 45, 45, .10);
    border-radius: 3px; box-shadow: 0 0 0 1px rgba(255,255,255,.7);
  }
  .hl-label {
    position: fixed; pointer-events: none; background: #ff2d2d; color: #fff; font-size: 12px; font-weight: 600;
    padding: 3px 7px; border-radius: 4px; max-width: 420px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
  }
  .hl-label b { font-weight: 800; }
  .area { position: fixed; pointer-events: none; border: 2px dashed #ff2d2d; background: rgba(255, 45, 45, .10); }
  .flash { position: fixed; pointer-events: none; border: 3px solid #ff2d2d; border-radius: 4px; animation: flash .5s ease-in-out 4 alternate; }
  @keyframes flash { from { opacity: 1; box-shadow: 0 0 0 6px rgba(255,45,45,.35); } to { opacity: .15; box-shadow: 0 0 0 0 rgba(255,45,45,0); } }

  /* --- note box --- */
  .note {
    position: fixed; width: 370px; pointer-events: auto; background: #fff; color: #222;
    border: 2px solid #e5503f; border-radius: 16px; box-shadow: 0 10px 40px rgba(0,0,0,.35); padding: 14px;
  }
  .note h3 { margin: 0 0 8px; font-size: 15px; font-weight: 800; color: #c2311f; }
  .note .what { font-size: 12px; color: #666; margin-bottom: 8px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .note textarea {
    width: 100%; min-height: 96px; resize: vertical; border: 2px solid #ddd; border-radius: 10px; padding: 10px;
    font-size: 15px; color: #222; background: #fff; outline: none;
  }
  .note textarea:focus { border-color: #ff8a7a; }
  .note textarea.bad { border-color: #ff2d2d; }
  .types { display: flex; margin: 10px 0 12px; border: 2px solid #e5503f; border-radius: 999px; overflow: hidden; }
  .types button { all: unset; flex: 1; text-align: center; padding: 8px 0; cursor: pointer; font-size: 12px; white-space: nowrap; font-weight: 700; color: #8f2a1d; }
  .types button + button { border-left: 1px solid #f1a397; }
  .types button.on { background: #ff8a7a; color: #3a0d07; }
  .row { display: flex; gap: 10px; }
  .btn { all: unset; cursor: pointer; flex: 1; text-align: center; padding: 12px 0; border-radius: 999px; font-size: 15px; font-weight: 800; }
  .btn.primary { background: #e5503f; color: #fff; }
  .btn.primary:hover { background: #cf3f2f; }
  .btn.ghost { background: #f1f1f1; color: #333; }
  .btn.ghost:hover { background: #e4e4e4; }
  .btn.danger { background: #fff; color: #c2311f; border: 2px solid #e5503f; padding: 10px 0; }
  .hint { font-size: 11px; color: #888; margin-top: 8px; text-align: center; }

  /* --- panel --- */
  .panel {
    position: fixed; top: 0; right: 0; bottom: 0; width: 400px; max-width: 100vw; pointer-events: auto;
    background: #fff; color: #222; box-shadow: -10px 0 40px rgba(0,0,0,.3); display: flex; flex-direction: column;
    transform: translateX(105%); transition: transform .22s ease;
  }
  .panel.open { transform: translateX(0); }
  .phead { display: flex; align-items: center; justify-content: space-between; padding: 16px 18px; background: #ff8a7a; color: #3a0d07; }
  .phead h2 { margin: 0; font-size: 18px; font-weight: 800; }
  .x { all: unset; cursor: pointer; font-size: 22px; width: 34px; height: 34px; text-align: center; line-height: 34px; border-radius: 999px; }
  .x:hover { background: rgba(255,255,255,.4); }
  .plist { flex: 1; overflow: auto; padding: 10px; }
  .empty { text-align: center; color: #888; padding: 40px 20px; font-size: 15px; line-height: 1.6; }
  .item { display: flex; gap: 10px; padding: 10px; border: 2px solid #eee; border-radius: 12px; margin-bottom: 8px; background: #fff; cursor: pointer; }
  .item:hover { border-color: #ffb0a4; }
  .item.dragging { opacity: .4; }
  .item.over { border-color: #e5503f; border-style: dashed; }
  .num { flex: none; width: 28px; height: 28px; border-radius: 999px; background: #e5503f; color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 13px; }
  .thumb.nopic { display: flex; align-items: center; justify-content: center; font-size: 22px; opacity: .6; }
  .thumb { flex: none; width: 76px; height: 56px; border-radius: 8px; background: #f3f3f3 center/contain no-repeat; border: 1px solid #ddd; }
  .body { flex: 1; min-width: 0; }
  .body .t { font-size: 11px; font-weight: 700; color: #c2311f; text-transform: uppercase; letter-spacing: .03em; }
  .body .n { font-size: 14px; color: #222; margin: 2px 0; white-space: pre-wrap; word-break: break-word; }
  .body .p { font-size: 11px; color: #888; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .body textarea { width: 100%; min-height: 60px; border: 2px solid #ff8a7a; border-radius: 8px; padding: 6px; font-size: 14px; resize: vertical; outline: none; }
  .acts { flex: none; display: flex; flex-direction: column; gap: 4px; }
  .ib { all: unset; cursor: pointer; width: 30px; height: 30px; border-radius: 8px; text-align: center; line-height: 30px; font-size: 15px; }
  .ib:hover { background: #ffe1dc; }
  .drag { cursor: grab; color: #aaa; }
  .pfoot { padding: 12px; border-top: 1px solid #eee; display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
  .pfoot .btn { padding: 11px 0; font-size: 14px; }
  .pfoot .wide { grid-column: span 2; }

  /* --- touch: confirm chips --- */
  .confirm { position: fixed; display: flex; gap: 6px; pointer-events: auto; }
  .confirm button {
    all: unset; cursor: pointer; background: #e5503f; color: #fff; font-size: 16px; font-weight: 800;
    padding: 11px 16px; border-radius: 999px; box-shadow: 0 4px 14px rgba(0,0,0,.35); border: 2px solid #e5503f;
  }
  .confirm button.ghost { background: #fff; color: #c2311f; }
  .grip, .shield { touch-action: none; }
  .bar .short { display: none; }
  .acts { display: grid; grid-template-columns: 30px 30px; grid-auto-rows: 30px; gap: 2px; align-content: start; }

  /* --- phones and narrow windows --- */
  @media (max-width: 640px) {
    .bar { font-size: 16px; }
    .bar button { padding: 13px 14px; font-size: 16px; }
    .bar .full { display: none; }
    .bar .short { display: inline; }
    .grip { width: 30px; }
    .note { left: 8px !important; right: 8px !important; top: 8px !important; width: auto !important; }
    .note textarea { font-size: 16px; min-height: 80px; }
    .types button { padding: 10px 0; }
    .panel { width: 100vw; }
    .ib { width: 38px; height: 38px; line-height: 38px; font-size: 17px; }
    .acts { grid-template-columns: 38px 38px; grid-auto-rows: 38px; }
    .thumb { width: 64px; height: 48px; }
    .hint { display: none; }
  }

  /* --- dialog + toast --- */
  .modal { position: fixed; inset: 0; background: rgba(0,0,0,.45); pointer-events: auto; display: flex; align-items: center; justify-content: center; }
  .dialog { background: #fff; color: #222; border-radius: 18px; padding: 22px; width: 320px; text-align: center; box-shadow: 0 10px 40px rgba(0,0,0,.4); }
  .dialog p { font-size: 16px; margin: 0 0 18px; font-weight: 600; }
  .s-text { font-size: 13px; color: #444; background: #fff4f2; border-radius: 10px; padding: 10px; margin: -6px 0 14px; text-align: left; word-break: break-word; }
  .col { display: flex; flex-direction: column; gap: 8px; }
  .pfoot .btn.primary.p-send + .btn.primary.p-dl { background: #fff; color: #c2311f; border: 2px solid #e5503f; padding: 9px 0; }
  .toast {
    position: fixed; left: 50%; bottom: 28px; transform: translateX(-50%); background: #3a0d07; color: #fff; pointer-events: none;
    padding: 12px 20px; border-radius: 999px; font-size: 14px; font-weight: 600; box-shadow: 0 6px 20px rgba(0,0,0,.35);
    max-width: 90vw; text-align: center;
  }
</style>

<div class="bar hidden" part="bar">
  <div class="grip" title="Drag to move">⋮⋮</div>
  <button class="b-pick" title="Point at something to fix (Esc cancels)">🎯 <span class="full">Claude To Fix</span><span class="short">Fix</span></button>
  <button class="b-list" title="See your fixes">📋 <span class="full">View Fix List</span><span class="short">List</span> <span class="count">0</span></button>
  <button class="b-dl" title="Download the fixes as a zip">⬇ <span class="full">Download File</span><span class="short">Zip</span></button>
</div>

<div class="shield hidden"></div>
<div class="area hidden"></div>
<div class="hl hidden"></div>
<div class="hl-label hidden"></div>
<div class="confirm hidden"><button class="c-yes">✔ This one</button><button class="ghost c-up">⬆ Bigger</button><button class="ghost c-no">✕</button></div>

<div class="note hidden">
  <h3>What should Claude fix?</h3>
  <div class="what"></div>
  <textarea placeholder="Type what's wrong or what to change…"></textarea>
  <div class="types"></div>
  <div class="row">
    <button class="btn primary n-save">Save</button>
    <button class="btn ghost n-cancel">Cancel</button>
  </div>
  <div class="hint">Ctrl + Enter saves · Esc cancels</div>
</div>

<div class="panel">
  <div class="phead"><h2>📋 Fix List <span class="p-count"></span></h2><button class="x p-close" title="Close">✕</button></div>
  <div class="plist"></div>
  <div class="pfoot">
    <button class="btn primary wide p-send hidden">📤 Send to Claude</button>
    <button class="btn primary wide p-dl">⬇ Download File</button>
    <button class="btn ghost p-copy">📄 Copy as text</button>
    <button class="btn danger p-clear">🗑 Clear All</button>
  </div>
</div>

<div class="modal hidden"><div class="dialog"><p class="m-text"></p><div class="row"><button class="btn primary m-yes">Yes</button><button class="btn ghost m-no">No</button></div></div></div>
<div class="modal sent hidden"><div class="dialog">
  <p class="s-title">✅ Sent to Claude</p>
  <div class="s-text"></div>
  <div class="col">
    <button class="btn primary s-copy">📋 Copy message for Claude</button>
    <button class="btn ghost s-open">🔗 Open on GitHub</button>
    <button class="btn danger s-clear">🗑 Clear my list</button>
    <button class="btn ghost s-close">Close</button>
  </div>
</div></div>
<div class="toast hidden"></div>
`;

  const $ = (s) => root.querySelector(s);
  const bar = $('.bar'), grip = $('.grip'), bPick = $('.b-pick'), bList = $('.b-list'), bDl = $('.b-dl'), count = $('.count');
  const shield = $('.shield'), hl = $('.hl'), hlLabel = $('.hl-label'), areaBox = $('.area');
  const note = $('.note'), noteText = note.querySelector('textarea'), noteWhat = $('.what'), typesBox = $('.types');
  const panel = $('.panel'), plist = $('.plist'), pCount = $('.p-count');
  const modal = $('.modal'), toastEl = $('.toast');

  function mount() {
    if (!host.isConnected) (document.documentElement || document.body).appendChild(host);
  }
  mount();
  // Some apps replace large parts of the DOM; put the bar back if it gets removed.
  new MutationObserver(() => { if (!host.isConnected) mount(); })
    .observe(document.documentElement, { childList: true });

  /* ---------------- small UI helpers ---------------- */

  let toastTimer = null;
  function toast(text, ms = 2600) {
    toastEl.textContent = text;
    toastEl.classList.remove('hidden');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.add('hidden'), ms);
  }

  function ask(text) {
    return new Promise((resolve) => {
      $('.m-text').textContent = text;
      modal.classList.remove('hidden');
      const done = (v) => { modal.classList.add('hidden'); $('.m-yes').onclick = $('.m-no').onclick = null; resolve(v); };
      $('.m-yes').onclick = () => done(true);
      $('.m-no').onclick = () => done(false);
    });
  }

  function setCount(n) {
    count.textContent = String(n);
    pCount.textContent = n ? `(${n})` : '';
  }

  async function refreshCount() {
    const r = await send({ cmd: 'listFixes' });
    setCount(r && r.fixes ? r.fixes.length : 0);
  }

  /* ---------------- bar position + drag ---------------- */

  function applyPosition() {
    bar.classList.remove('pos-top-center', 'pos-top-right', 'pos-bottom-right', 'custom');
    bar.style.left = bar.style.top = '';
    api.storage.local.get('barPos').then(({ barPos }) => {
      if (barPos && barPos.forPosition === settings.position) {
        const x = Math.min(Math.max(0, barPos.x * window.innerWidth), window.innerWidth - 80);
        const y = Math.min(Math.max(0, barPos.y * window.innerHeight), window.innerHeight - 40);
        bar.classList.add('custom');
        bar.style.left = x + 'px';
        bar.style.top = y + 'px';
      } else {
        bar.classList.add('pos-' + (settings.position || 'top-center'));
      }
    });
  }

  grip.addEventListener('pointerdown', (e) => {
    e.preventDefault();
    try { grip.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
    const r = bar.getBoundingClientRect();
    const dx = e.clientX - r.left, dy = e.clientY - r.top;
    bar.classList.remove('pos-top-center', 'pos-top-right', 'pos-bottom-right');
    bar.classList.add('custom');
    bar.style.left = r.left + 'px';
    bar.style.top = r.top + 'px';
    const move = (ev) => {
      const x = Math.min(Math.max(0, ev.clientX - dx), window.innerWidth - r.width);
      const y = Math.min(Math.max(0, ev.clientY - dy), window.innerHeight - r.height);
      bar.style.left = x + 'px';
      bar.style.top = y + 'px';
    };
    const up = () => {
      grip.removeEventListener('pointermove', move);
      grip.removeEventListener('pointerup', up);
      grip.removeEventListener('pointercancel', up);
      const b = bar.getBoundingClientRect();
      api.storage.local.set({ barPos: { x: b.left / window.innerWidth, y: b.top / window.innerHeight, forPosition: settings.position } });
    };
    grip.addEventListener('pointermove', move);
    grip.addEventListener('pointerup', up);
    grip.addEventListener('pointercancel', up);
  });
  grip.addEventListener('dblclick', () => { api.storage.local.remove('barPos').then(applyPosition); });

  /* ---------------- show / hide ---------------- */

  function show() {
    mount();
    visible = true;
    bar.classList.remove('hidden');
    applyPosition();
    refreshCount();
  }
  function hide() {
    visible = false;
    stopPick();
    closeNote();
    closePanel();
    bar.classList.add('hidden');
  }
  function toggle() {
    userTouched = true;
    if (visible) hide(); else show();
    send({ cmd: 'rememberHidden', url: location.href, hidden: !visible });
    return visible;
  }

  /* ---------------- element description ---------------- */

  const esc = (s) => (window.CSS && CSS.escape ? CSS.escape(s) : String(s).replace(/[^\w-]/g, '\\$&'));
  const uniq = (sel) => { try { return document.querySelectorAll(sel).length === 1; } catch (e) { return false; } };
  const STABLE_ATTRS = ['data-guide', 'data-testid', 'data-test', 'data-test-id', 'data-cy', 'data-qa'];
  const goodClass = (c) => /^[A-Za-z_][\w-]{0,39}$/.test(c) && !/\d{4,}|^(css|sc|jsx|svelte|emotion)-|^ng-|^_|__[A-Za-z0-9]{5,}$/.test(c);
  const goodId = (id) => /^[A-Za-z][\w-]*$/.test(id) && !/\d{4,}/.test(id) && !/^(ember|react|radix|headlessui|mui)/i.test(id);

  function segment(el) {
    if (el.id && goodId(el.id) && uniq('#' + esc(el.id))) return { sel: '#' + esc(el.id), anchor: true };
    for (const a of STABLE_ATTRS) {
      const v = el.getAttribute(a);
      if (v) {
        const s = `[${a}="${String(v).replace(/"/g, '\\"')}"]`;
        if (uniq(s)) return { sel: s, anchor: true };
      }
    }
    let s = el.tagName.toLowerCase();
    const cls = [...el.classList].filter(goodClass).slice(0, 2);
    s += cls.map((c) => '.' + esc(c)).join('');
    const p = el.parentElement;
    if (p) {
      const kids = [...p.children];
      let same = 0;
      try { same = kids.filter((k) => k.matches(s)).length; } catch (e) { same = 2; }
      if (same > 1) s += `:nth-child(${kids.indexOf(el) + 1})`;
    }
    return { sel: s, anchor: false };
  }

  function buildSelector(el) {
    const parts = [];
    let cur = el;
    for (let depth = 0; cur && cur.nodeType === 1 && cur !== document.documentElement && depth < 10; depth++) {
      const seg = segment(cur);
      parts.unshift(seg.sel);
      const full = parts.join(' > ');
      if (seg.anchor || uniq(full)) {
        // Try to shorten: anchor + descendant path of just the picked element.
        if (parts.length > 2) {
          const short = parts[0] + ' ' + parts[parts.length - 1];
          if (uniq(short)) return short;
        }
        return full;
      }
      cur = cur.parentElement;
    }
    return parts.join(' > ');
  }

  function shortName(el) {
    let s = el.tagName.toLowerCase();
    if (el.id) s += '#' + el.id;
    const cls = [...el.classList].slice(0, 3);
    if (cls.length) s += '.' + cls.join('.');
    return s;
  }

  const FORM_TAGS = new Set(['INPUT', 'TEXTAREA', 'SELECT']);
  function visibleText(el) {
    // Never read what someone typed into a form box.
    if (FORM_TAGS.has(el.tagName)) {
      const label = el.getAttribute('aria-label') || el.getAttribute('placeholder') || el.getAttribute('name') || el.getAttribute('type') || '';
      return label ? `[${el.tagName.toLowerCase()}: ${label}]`.slice(0, 120) : '';
    }
    let t = '';
    if (el.isContentEditable) t = el.getAttribute('aria-label') || '';
    else t = el.innerText || el.textContent || el.getAttribute('aria-label') || el.getAttribute('title') || el.getAttribute('alt') || '';
    return t.replace(/\s+/g, ' ').trim().slice(0, 120);
  }

  function hex(c) {
    const m = String(c).match(/rgba?\(([^)]+)\)/);
    if (!m) return c;
    const p = m[1].split(/[\s,\/]+/).filter(Boolean).map(Number);
    const [r, g, b] = p;
    const a = p.length > 3 ? p[3] : 1;
    if (a === 0) return 'transparent';
    const h = '#' + [r, g, b].map((v) => Math.round(v).toString(16).padStart(2, '0')).join('');
    return a < 1 ? `${h} @ ${Math.round(a * 100)}%` : h;
  }

  function effectiveBg(el) {
    for (let cur = el; cur && cur.nodeType === 1; cur = cur.parentElement) {
      const bg = getComputedStyle(cur).backgroundColor;
      if (hex(bg) !== 'transparent') return hex(bg);
    }
    return 'transparent';
  }

  function describe(el) {
    const cs = getComputedStyle(el);
    const data = {};
    for (const a of el.attributes) {
      if (a.name.startsWith('data-')) data[a.name] = String(a.value).slice(0, 80);
    }
    const attrs = {};
    ['role', 'aria-label', 'title', 'name', 'type', 'href', 'alt'].forEach((n) => {
      const v = el.getAttribute(n);
      if (v) attrs[n] = String(v).slice(0, 120);
    });
    const parents = [];
    for (let p = el.parentElement, i = 0; p && i < 3 && p !== document.documentElement; p = p.parentElement, i++) {
      let s = p.tagName.toLowerCase();
      if (p.id) s += '#' + p.id;
      const cls = [...p.classList].slice(0, 2);
      if (cls.length) s += '.' + cls.join('.');
      parents.push(s);
    }
    const r = el.getBoundingClientRect();
    return {
      tag: el.tagName.toLowerCase(),
      id: el.id || '',
      classes: [...el.classList],
      data,
      attrs,
      short: shortName(el),
      selector: buildSelector(el),
      text: visibleText(el),
      size: { w: Math.round(r.width), h: Math.round(r.height) },
      position: { x: Math.round(r.left), y: Math.round(r.top), pageX: Math.round(r.left + scrollX), pageY: Math.round(r.top + scrollY) },
      styles: {
        fontSize: cs.fontSize,
        fontWeight: cs.fontWeight,
        fontFamily: (cs.fontFamily || '').split(',')[0].replace(/["']/g, '').trim(),
        color: hex(cs.color),
        background: hex(cs.backgroundColor),
        effectiveBackground: effectiveBg(el),
        borderRadius: cs.borderRadius,
        padding: cs.padding,
        margin: cs.margin,
        width: cs.width,
        height: cs.height
      },
      parents
    };
  }

  // For an area pick: the visible elements that sit fully inside it and show their own text.
  function insideArea(r) {
    const out = [];
    const all = document.body ? document.body.querySelectorAll('*') : [];
    for (const el of all) {
      if (out.length >= 8) break;
      if (el === host) continue;
      const b = el.getBoundingClientRect();
      if (!b.width || !b.height) continue;
      if (b.left < r.left - 2 || b.top < r.top - 2 || b.right > r.left + r.width + 2 || b.bottom > r.top + r.height + 2) continue;
      const own = [...el.childNodes].some((n) => n.nodeType === 3 && n.textContent.trim()) || FORM_TAGS.has(el.tagName) || el.tagName === 'IMG' || el.tagName === 'svg';
      if (!own) continue;
      out.push({ short: shortName(el), selector: buildSelector(el), text: visibleText(el).slice(0, 60) });
    }
    return out;
  }

  function themeInfo() {
    const html = document.documentElement;
    const body = document.body;
    const prefersDark = window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches;
    const dataTheme = html.getAttribute('data-theme') || '';
    const dataLook = html.getAttribute('data-look') || '';
    const classes = ((html.className || '') + ' ' + ((body && body.className) || '')).toString();
    let label = prefersDark ? 'Dark' : 'Light';
    const hint = (dataTheme + ' ' + dataLook + ' ' + classes).toLowerCase();
    if (/\bdark\b/.test(hint)) label = 'Dark';
    else if (/\blight\b/.test(hint)) label = 'Light';
    return { label, prefersDark, dataTheme, dataLook, colorScheme: getComputedStyle(html).colorScheme || '' };
  }

  /* ---------------- pick mode ---------------- */

  let hoverEl = null;
  let drag = null;           // { x, y } start for shift+drag area
  let pick = null;           // current pick: { el, area, rect(page coords) }
  let currentType = 'Style';

  function underlying(x, y) {
    const list = document.elementsFromPoint(x, y);
    for (const el of list) {
      if (el === host || el === document.documentElement || el === document.body) continue;
      return el;
    }
    return document.body;
  }

  function placeHighlight(rect, label) {
    hl.style.left = rect.left - 2 + 'px';
    hl.style.top = rect.top - 2 + 'px';
    hl.style.width = rect.width + 4 + 'px';
    hl.style.height = rect.height + 4 + 'px';
    hl.classList.remove('hidden');
    if (label) {
      hlLabel.innerHTML = '';
      const b = document.createElement('b');
      b.textContent = label.tag;
      hlLabel.append(b, document.createTextNode(label.text ? '  ' + label.text : ''));
      const ly = rect.top > 26 ? rect.top - 24 : rect.bottom + 4;
      hlLabel.style.left = Math.max(4, Math.min(rect.left, window.innerWidth - 300)) + 'px';
      hlLabel.style.top = ly + 'px';
      hlLabel.classList.remove('hidden');
    } else hlLabel.classList.add('hidden');
  }

  function clearHighlight() {
    hl.classList.add('hidden');
    hlLabel.classList.add('hidden');
  }

  function labelFor(el) {
    let tag = el.tagName.toLowerCase();
    const cls = [...el.classList].slice(0, 2);
    if (el.id) tag += '#' + el.id;
    else if (cls.length) tag += '.' + cls.join('.');
    const t = visibleText(el);
    return { tag, text: t.length > 40 ? t.slice(0, 40) + '…' : t };
  }

  function startPick() {
    if (busy) return;
    closeNote();
    closePanel();
    picking = true;
    bPick.classList.add('on');
    shield.classList.remove('hidden');
    toast(isTouch() ? 'Tap something to fix · Drag a finger for an area' : 'Click something to fix · Drag for an area · Esc to cancel', 3500);
  }

  function stopPick() {
    picking = false;
    drag = null;
    bPick.classList.remove('on');
    shield.classList.add('hidden');
    areaBox.classList.add('hidden');
    hideConfirm();
    if (note.classList.contains('hidden')) clearHighlight();
  }

  const isTouch = () => window.matchMedia && matchMedia('(pointer: coarse)').matches;
  const confirmBox = $('.confirm');
  let candidate = null;

  function hideConfirm() {
    confirmBox.classList.add('hidden');
    candidate = null;
  }

  // Touch: tap shows a preview box, then ✔ / ⬆ Bigger / ✕.
  function showConfirm(el) {
    candidate = el;
    const r = el.getBoundingClientRect();
    placeHighlight(r, labelFor(el));
    confirmBox.classList.remove('hidden');
    const cw = confirmBox.offsetWidth || 280, chh = confirmBox.offsetHeight || 46;
    let y = r.bottom + 10;
    if (y + chh > window.innerHeight - 8) y = Math.max(8, r.top - chh - 30);
    const x = Math.max(8, Math.min(window.innerWidth - cw - 8, r.left));
    confirmBox.style.left = x + 'px';
    confirmBox.style.top = y + 'px';
  }
  $('.c-yes').onclick = (e) => { e.stopPropagation(); if (candidate) { const el = candidate; hideConfirm(); finishPick({ el, area: false }); } };
  $('.c-up').onclick = (e) => {
    e.stopPropagation();
    if (!candidate) return;
    const p = candidate.parentElement;
    if (p && p !== document.body && p !== document.documentElement) showConfirm(p);
    else toast('That is already the biggest part');
  };
  $('.c-no').onclick = (e) => { e.stopPropagation(); hideConfirm(); clearHighlight(); };

  function areaRect(d, e) {
    return {
      x: Math.min(d.x, e.clientX), y: Math.min(d.y, e.clientY),
      w: Math.abs(e.clientX - d.x), h: Math.abs(e.clientY - d.y)
    };
  }

  shield.addEventListener('pointermove', (e) => {
    if (drag) {
      const a = areaRect(drag, e);
      if (!drag.moved && (a.w > 8 || a.h > 8)) { drag.moved = true; hideConfirm(); }
      if (drag.moved) {
        Object.assign(areaBox.style, { left: a.x + 'px', top: a.y + 'px', width: a.w + 'px', height: a.h + 'px' });
        areaBox.classList.remove('hidden');
        clearHighlight();
      }
      return;
    }
    if (e.pointerType !== 'mouse') return;
    const el = underlying(e.clientX, e.clientY);
    if (el !== hoverEl) {
      hoverEl = el;
      placeHighlight(el.getBoundingClientRect(), labelFor(el));
    }
  });

  shield.addEventListener('pointerdown', (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.button !== 0) return;
    try { shield.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
    drag = { x: e.clientX, y: e.clientY, moved: false, touch: e.pointerType !== 'mouse' };
  });

  shield.addEventListener('pointerup', (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!drag) return;
    const d = drag;
    drag = null;
    areaBox.classList.add('hidden');
    const a = areaRect(d, e);
    if (d.moved && a.w > 6 && a.h > 6) {
      hideConfirm();
      const centre = underlying(a.x + a.w / 2, a.y + a.h / 2);
      finishPick({ el: centre, area: true, rect: { x: a.x + scrollX, y: a.y + scrollY, w: a.w, h: a.h } });
      return;
    }
    const el = underlying(e.clientX, e.clientY);
    if (d.touch) showConfirm(el);
    else finishPick({ el, area: false });
  });
  shield.addEventListener('pointercancel', () => { drag = null; areaBox.classList.add('hidden'); });
  // Stop the page reacting to taps/clicks that land on the shield.
  ['click', 'mousedown', 'mouseup', 'touchstart', 'touchend'].forEach((t) =>
    shield.addEventListener(t, (e) => { e.preventDefault(); e.stopPropagation(); }, { passive: false }));

  shield.addEventListener('contextmenu', (e) => { e.preventDefault(); stopPick(); });

  function pickRectNow() {
    // Viewport rect for the current pick (follows scrolling).
    if (!pick) return null;
    if (pick.area) return { left: pick.rect.x - scrollX, top: pick.rect.y - scrollY, width: pick.rect.w, height: pick.rect.h };
    const r = pick.el.isConnected ? pick.el.getBoundingClientRect() : null;
    return r ? { left: r.left, top: r.top, width: r.width, height: r.height } : pick.lastRect;
  }

  function finishPick(p) {
    pick = p;
    if (!p.area) {
      const r = p.el.getBoundingClientRect();
      pick.lastRect = { left: r.left, top: r.top, width: r.width, height: r.height };
    }
    stopPick();
    openNote();
  }

  /* ---------------- note box ---------------- */

  TYPES.forEach((t) => {
    const b = document.createElement('button');
    b.textContent = `${TYPE_ICON[t]} ${t}`;
    b.dataset.type = t;
    b.onclick = () => setType(t);
    typesBox.appendChild(b);
  });
  function setType(t) {
    currentType = t;
    typesBox.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.type === t));
  }

  function positionNote() {
    const r = pickRectNow();
    if (!r) return;
    placeHighlight(r, pick.area ? { tag: 'area', text: `${Math.round(r.width)}×${Math.round(r.height)}` } : labelFor(pick.el));
    const W = 370, H = note.offsetHeight || 300, gap = 14, vw = window.innerWidth, vh = window.innerHeight;
    let x, y;
    if (r.left + r.width + gap + W < vw) x = r.left + r.width + gap;
    else if (r.left - gap - W > 0) x = r.left - gap - W;
    else x = Math.max(8, Math.min(vw - W - 8, r.left));
    y = Math.max(8, Math.min(vh - H - 8, r.top));
    if (x === Math.max(8, Math.min(vw - W - 8, r.left))) {
      // No room beside it: go below or above.
      if (r.top + r.height + gap + H < vh) y = r.top + r.height + gap;
      else if (r.top - gap - H > 0) y = r.top - gap - H;
    }
    note.style.left = x + 'px';
    note.style.top = y + 'px';
  }

  function openNote() {
    noteText.value = '';
    noteText.classList.remove('bad');
    setType(settings.defaultType || 'Style');
    noteWhat.textContent = pick.area
      ? `Area ${Math.round(pick.rect.w)}×${Math.round(pick.rect.h)}`
      : `${labelFor(pick.el).tag}  ${visibleText(pick.el).slice(0, 60)}`;
    note.classList.remove('hidden');
    positionNote();
    setTimeout(() => noteText.focus(), 0);
  }

  function closeNote() {
    note.classList.add('hidden');
    pick = null;
    clearHighlight();
  }

  noteText.addEventListener('keydown', (e) => {
    e.stopPropagation();
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); saveFix(); }
    if (e.key === 'Escape') { e.preventDefault(); closeNote(); }
  });
  // Keep the site's keyboard shortcuts from firing while typing in our boxes.
  ['keyup', 'keypress', 'input'].forEach((t) => note.addEventListener(t, (e) => e.stopPropagation()));
  $('.n-cancel').onclick = closeNote;
  $('.n-save').onclick = () => saveFix();

  const nextFrame = () => new Promise((r) => requestAnimationFrame(() => r()));
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));

  function blurForms(on) {
    const id = 'claude-to-fix-blur';
    let st = document.getElementById(id);
    if (on) {
      if (!st) {
        st = document.createElement('style');
        st.id = id;
        st.textContent = 'input:not([type=button]):not([type=submit]):not([type=checkbox]):not([type=radio]):not([type=range]), textarea, select, [contenteditable=""], [contenteditable="true"] { filter: blur(6px) !important; }';
        (document.head || document.documentElement).appendChild(st);
      }
    } else if (st) st.remove();
  }

  async function saveFix() {
    if (busy || !pick) return;
    const text = noteText.value.trim();
    if (!text) {
      noteText.classList.add('bad');
      noteText.focus();
      toast('Please type a note first');
      return;
    }
    busy = true;
    const r = pickRectNow();
    const el = pick.el;
    const fix = {
      note: text,
      type: currentType,
      title: document.title,
      pageName: document.title || location.pathname,
      url: location.href,
      screen: { w: screen.width, h: screen.height, dpr: window.devicePixelRatio || 1 },
      viewport: { w: window.innerWidth, h: window.innerHeight },
      scroll: { x: Math.round(scrollX), y: Math.round(scrollY) },
      theme: themeInfo(),
      area: !!pick.area,
      rect: r ? { x: r.left, y: r.top, w: r.width, h: r.height } : null,
      element: el && el.isConnected && !(pick.area && (el === document.body || el === document.documentElement)) ? describe(el) : null,
      inside: pick.area && r ? insideArea(r) : undefined
    };

    // Hide our UI (and blur form boxes) for a clean screenshot.
    host.style.setProperty('visibility', 'hidden', 'important');
    if (settings.blurForms) blurForms(true);
    await nextFrame(); await nextFrame(); await wait(60);
    let res = null;
    try { res = await send({ cmd: 'saveFix', fix }); }
    finally {
      blurForms(false);
      host.style.removeProperty('visibility');
      busy = false;
    }
    closeNote();
    if (res && res.ok) {
      setCount(res.count);
      toast(res.warning ? `Fix #${res.number} saved. ${res.warning}` : `✅ Fix #${res.number} saved`, res.warning ? 5000 : 2200);
      if (panel.classList.contains('open')) renderList();
    } else {
      toast('Could not save that fix. Please try again.');
    }
  }

  window.addEventListener('scroll', () => { if (!note.classList.contains('hidden')) positionNote(); }, true);
  window.addEventListener('resize', () => { if (!note.classList.contains('hidden')) positionNote(); if (visible) applyPosition(); });

  // Ctrl+Alt+F toggles the bar on any page where this script is running.
  window.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.altKey && !e.shiftKey && !e.metaKey && (e.code === 'KeyF' || String(e.key).toLowerCase() === 'f')) {
      e.preventDefault();
      e.stopPropagation();
      toggle();
    }
  }, true);

  window.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    if (picking) { e.preventDefault(); e.stopPropagation(); stopPick(); }
    else if (!modal.classList.contains('hidden')) { e.stopPropagation(); modal.querySelector('.m-no').click(); }
    else if (panel.classList.contains('open')) { e.stopPropagation(); closePanel(); }
  }, true);

  /* ---------------- fix list panel ---------------- */

  function openPanel() {
    closeNote();
    stopPick();
    panel.classList.add('open');
    bList.classList.add('on');
    renderList();
  }
  function closePanel() {
    panel.classList.remove('open');
    bList.classList.remove('on');
  }

  let dragId = null;
  let lastRendered = '';
  let rerenderTimer = null;

  async function renderList() {
    const r = await send({ cmd: 'listFixes' });
    const fixes = (r && r.fixes) || [];
    $('.p-send').classList.toggle('hidden', !(r && r.cloud && r.cloud.gh));
    lastRendered = fixes.map((f) => f.id + ':' + (f.updated || '')).join(',');
    setCount(fixes.length);
    plist.innerHTML = '';
    if (!fixes.length) {
      const d = document.createElement('div');
      d.className = 'empty';
      d.innerHTML = 'No fixes yet.<br>Press <b>🎯 Claude To Fix</b>, then click something on the page.';
      plist.appendChild(d);
      return;
    }
    fixes.forEach((f, i) => {
      const item = document.createElement('div');
      item.className = 'item';
      item.draggable = true;
      item.dataset.id = f.id;

      const num = document.createElement('div');
      num.className = 'num';
      num.textContent = String(i + 1);

      const thumb = document.createElement('div');
      thumb.className = 'thumb';
      if (!f.hasCrop && !f.hasFull) {
        thumb.classList.add('nopic');
        thumb.textContent = '🖥';
        thumb.title = 'No picture on this computer (made on another one, or no screenshot)';
      }
      if (f.hasCrop || f.hasFull || f.cloud) {
        thumb.classList.remove('nopic');
        thumb.textContent = '';
        send({ cmd: 'getThumb', id: f.id }).then((t) => { if (t && t.url) thumb.style.backgroundImage = `url("${t.url}")`; });
      }

      const body = document.createElement('div');
      body.className = 'body';
      const t = document.createElement('div');
      t.className = 't';
      t.textContent = `${TYPE_ICON[f.type] || ''} ${f.type}`;
      const n = document.createElement('div');
      n.className = 'n';
      n.textContent = f.note;
      const p = document.createElement('div');
      p.className = 'p';
      p.textContent = f.pageName || f.url;
      p.title = f.url;
      body.append(t, n, p);

      const acts = document.createElement('div');
      acts.className = 'acts';
      const bEdit = document.createElement('button');
      bEdit.className = 'ib'; bEdit.textContent = '✏️'; bEdit.title = 'Edit note';
      const bDel = document.createElement('button');
      bDel.className = 'ib'; bDel.textContent = '🗑'; bDel.title = 'Delete';
      const bUp = document.createElement('button');
      bUp.className = 'ib'; bUp.textContent = '▲'; bUp.title = 'Move up';
      const bDown = document.createElement('button');
      bDown.className = 'ib'; bDown.textContent = '▼'; bDown.title = 'Move down';
      if (i === 0) bUp.style.visibility = 'hidden';
      if (i === fixes.length - 1) bDown.style.visibility = 'hidden';
      acts.append(bEdit, bDel, bUp, bDown);
      const move = async (e, by) => {
        e.stopPropagation();
        const ids = fixes.map((x) => x.id);
        const j = i + by;
        if (j < 0 || j >= ids.length) return;
        [ids[i], ids[j]] = [ids[j], ids[i]];
        await send({ cmd: 'reorder', ids });
        renderList();
      };
      bUp.onclick = (e) => move(e, -1);
      bDown.onclick = (e) => move(e, 1);

      item.append(num, thumb, body, acts);
      plist.appendChild(item);

      bEdit.onclick = (e) => {
        e.stopPropagation();
        const ta = document.createElement('textarea');
        ta.value = f.note;
        n.replaceWith(ta);
        ta.focus();
        item.draggable = false;
        let finished = false;
        const done = async (saveIt) => {
          if (finished) return;
          finished = true;
          if (saveIt && ta.value.trim()) {
            await send({ cmd: 'updateFix', id: f.id, changes: { note: ta.value.trim() } });
            toast('Note updated');
          }
          renderList();
        };
        ta.addEventListener('click', (ev) => ev.stopPropagation());
        ta.addEventListener('keydown', (ev) => {
          ev.stopPropagation();
          if (ev.key === 'Enter' && (ev.ctrlKey || ev.metaKey)) done(true);
          if (ev.key === 'Escape') done(false);
        });
        ['keyup', 'keypress', 'input'].forEach((tp) => ta.addEventListener(tp, (ev) => ev.stopPropagation()));
        ta.addEventListener('blur', () => done(true), { once: true });
      };
      bDel.onclick = async (e) => {
        e.stopPropagation();
        if (!(await ask(`Delete fix #${i + 1}?`))) return;
        await send({ cmd: 'deleteFix', id: f.id });
        renderList();
      };
      item.onclick = () => openFix(f);

      item.addEventListener('dragstart', (e) => {
        dragId = f.id;
        item.classList.add('dragging');
        e.dataTransfer.effectAllowed = 'move';
        try { e.dataTransfer.setData('text/plain', f.id); } catch (err) { /* ignore */ }
      });
      item.addEventListener('dragend', () => { item.classList.remove('dragging'); dragId = null; });
      item.addEventListener('dragover', (e) => { e.preventDefault(); item.classList.add('over'); });
      item.addEventListener('dragleave', () => item.classList.remove('over'));
      item.addEventListener('drop', async (e) => {
        e.preventDefault();
        item.classList.remove('over');
        if (!dragId || dragId === f.id) return;
        const ids = fixes.map((x) => x.id).filter((id) => id !== dragId);
        const to = ids.indexOf(f.id);
        const from = fixes.findIndex((x) => x.id === dragId);
        ids.splice(from <= i ? to + 1 : to, 0, dragId);
        await send({ cmd: 'reorder', ids });
        renderList();
      });
    });
  }

  function sameUrl(a, b) {
    try {
      const x = new URL(a), y = new URL(b);
      return x.origin === y.origin && x.pathname.replace(/\/$/, '') === y.pathname.replace(/\/$/, '') && x.search === y.search && x.hash === y.hash;
    } catch (e) { return a === b; }
  }

  async function openFix(f) {
    if (sameUrl(f.url, location.href)) {
      closePanel();
      flash(f.element && f.element.selector, f.area ? f.rect : null, f);
    } else {
      toast('Opening that page…');
      await send({ cmd: 'openFix', id: f.id });
    }
  }

  function flash(selector, rect, f) {
    let el = null;
    if (selector) { try { el = document.querySelector(selector); } catch (e) { el = null; } }
    const box = document.createElement('div');
    box.className = 'flash';
    const place = (r) => Object.assign(box.style, { left: r.left - 4 + 'px', top: r.top - 4 + 'px', width: r.width + 8 + 'px', height: r.height + 8 + 'px' });
    if (el && !(f && f.area)) {
      el.scrollIntoView({ block: 'center', behavior: 'instant' });
      place(el.getBoundingClientRect());
    } else if (rect && f && f.scroll) {
      window.scrollTo(f.scroll.x, f.scroll.y);
      place({ left: rect.x, top: rect.y, width: rect.w, height: rect.h });
    } else {
      toast("Couldn't find that part on this page any more");
      return;
    }
    root.appendChild(box);
    setTimeout(() => box.remove(), 2200);
  }

  /* ---------------- download / copy / clear ---------------- */

  async function download() {
    toast('Making the zip…', 1500);
    const r = await send({ cmd: 'download' });
    if (r && !r.ok && r.dataUrl) {
      // Browser's download API not available (e.g. some Android builds): save from the page instead.
      const [head, b64] = r.dataUrl.split(',');
      const bin = atob(b64);
      const bytes = new Uint8Array(bin.length);
      for (let k = 0; k < bin.length; k++) bytes[k] = bin.charCodeAt(k);
      const blob = new Blob([bytes], { type: (head.match(/data:([^;]+)/) || [])[1] || 'application/zip' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = r.name;
      root.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 60000);
      return toast(`⬇ Downloaded ${r.name}`, 3500);
    }
    if (r && r.ok) toast(`⬇ Downloaded ${r.name}`, 3500);
    else toast((r && r.error) || 'Download failed');
  }

  async function copyText() {
    const r = await send({ cmd: 'getMarkdown' });
    if (!r || !r.text) return toast('Nothing to copy');
    try {
      await navigator.clipboard.writeText(r.text);
    } catch (e) {
      const ta = document.createElement('textarea');
      ta.value = r.text;
      root.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
    }
    toast('📄 Copied the fix list as text (no pictures)');
  }

  /* ---------------- send to Claude (GitHub) ---------------- */

  const sentModal = $('.modal.sent');
  let sent = null;
  async function sendToClaude() {
    if (busy) return;
    busy = true;
    toast('📤 Sending to Claude…', 20000);
    let r = null;
    try { r = await send({ cmd: 'sendToClaude' }); } finally { busy = false; }
    if (!r || !r.ok) return toast(`❌ ${(r && r.error) || 'Could not send'}`, 6000);
    toastEl.classList.add('hidden');
    sent = r;
    $('.s-text').textContent = r.message;
    $('.s-title').textContent = `✅ Sent ${r.count} fix${r.count === 1 ? '' : 'es'} to Claude`;
    sentModal.classList.remove('hidden');
  }
  $('.s-copy').onclick = async () => {
    try { await navigator.clipboard.writeText(sent.message); }
    catch (e) {
      const ta = document.createElement('textarea');
      ta.value = sent.message; root.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove();
    }
    toast('📋 Copied. Paste it in your Claude thread.');
  };
  $('.s-open').onclick = () => window.open(sent.url, '_blank', 'noopener');
  $('.s-clear').onclick = async () => {
    sentModal.classList.add('hidden');
    await send({ cmd: 'clearAll' });
    renderList();
    toast('List cleared. Your fixes are safe on GitHub.');
  };
  $('.s-close').onclick = () => sentModal.classList.add('hidden');

  async function clearAll() {
    if (!(await ask('Delete ALL fixes? This can\'t be undone.'))) return;
    await send({ cmd: 'clearAll' });
    renderList();
    toast('List cleared');
  }

  /* ---------------- wiring ---------------- */

  bPick.onclick = () => (picking ? stopPick() : startPick());
  bList.onclick = () => (panel.classList.contains('open') ? closePanel() : openPanel());
  bDl.onclick = download;
  $('.p-close').onclick = closePanel;
  $('.p-dl').onclick = download;
  $('.p-send').onclick = sendToClaude;
  $('.p-copy').onclick = copyText;
  $('.p-clear').onclick = clearAll;

  api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg) return;
    if (msg.cmd === 'toggle') sendResponse({ visible: toggle() });
    else if (msg.cmd === 'show') { userTouched = true; show(); sendResponse({ visible: true }); }
    else if (msg.cmd === 'flash') { flash(msg.selector, msg.rect, { area: !!msg.area, scroll: msg.scroll }); sendResponse({ ok: true }); }
  });

  api.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.settings) {
      settings = Object.assign(settings, changes.settings.newValue || {});
      if (visible) applyPosition();
    }
    if (changes.fixes && visible) {
      const list = changes.fixes.newValue || [];
      setCount(list.length);
      // Changes from another computer (via sync) or another tab: refresh the open list.
      const ids = list.map((f) => f.id + ':' + (f.updated || '')).join(',');
      if (panel.classList.contains('open') && ids !== lastRendered && !(root.activeElement && root.activeElement.tagName === 'TEXTAREA')) {
        clearTimeout(rerenderTimer);
        rerenderTimer = setTimeout(renderList, 300);
      }
    }
  });

  (async () => {
    const s = await send({ cmd: 'getSettings' });
    if (s) settings = Object.assign(settings, s);
    const r = await send({ cmd: 'shouldAutoShow', url: location.href });
    if (r && r.show && !userTouched) show();
  })();
})();
