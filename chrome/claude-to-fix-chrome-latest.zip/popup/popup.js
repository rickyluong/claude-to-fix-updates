const api = globalThis.browser && globalThis.browser.runtime ? globalThis.browser : globalThis.chrome;
const send = (msg) => api.runtime.sendMessage(msg).catch(() => null);
const $ = (id) => document.getElementById(id);

let settings = null;
$('ver').textContent = 'v' + api.runtime.getManifest().version;
let currentOrigin = null;

function pattern(origin) {
  const u = new URL(origin);
  return `${u.protocol}//${u.hostname}/*`;
}

function normalise(input) {
  let s = String(input || '').trim();
  if (!s) return null;
  if (!/^https?:\/\//i.test(s)) s = 'https://' + s;
  try { return new URL(s).origin; } catch (e) { return null; }
}

function showMsg(text) {
  const m = $('msg');
  m.textContent = text;
  m.classList.toggle('hidden', !text);
}

function setSeg(id, value) {
  document.querySelectorAll(`#${id} button`).forEach((b) => b.classList.toggle('on', b.dataset.v === value));
}

function render() {
  setSeg('mode', settings.mode);
  setSeg('position', settings.position);
  setSeg('defaultType', settings.defaultType);
  $('blurForms').checked = !!settings.blurForms;
  $('listBox').classList.toggle('hidden', settings.mode !== 'list');
  let note = '';
  if (!settings.mode) note = 'Right now the bar only shows when you press the button above or Ctrl + Alt + F.';
  else if (settings.mode === 'site') note = settings.siteOrigin ? `Shows by itself on ${new URL(settings.siteOrigin).host}` : '';
  else if (settings.mode === 'all') note = 'Shows by itself on every website.';
  else note = 'Shows by itself on the sites below.';
  $('modeNote').textContent = note;
  const box = $('sites');
  box.innerHTML = '';
  (settings.sites || []).forEach((o) => {
    const row = document.createElement('div');
    row.className = 'site';
    const name = document.createElement('span');
    name.textContent = new URL(o).host;
    const del = document.createElement('button');
    del.textContent = '✕';
    del.title = 'Remove';
    del.onclick = () => save({ sites: settings.sites.filter((x) => x !== o) });
    row.append(name, del);
    box.appendChild(row);
  });
}

async function save(changes) {
  settings = await send({ cmd: 'setSettings', settings: changes });
  render();
}

// Ask the browser for permission to run on these sites. Must run straight from a click.
function allow(origins) {
  if (!origins.length) return Promise.resolve(true);
  try {
    return Promise.resolve(api.permissions.request({ origins })).catch(() => false);
  } catch (e) {
    return Promise.resolve(false);
  }
}

// Note: permissions.request() is called first and synchronously inside the click,
// and the setting is saved at the same moment, in case the browser closes this popup
// while it shows its permission prompt.
const NO = 'The browser said no, so the bar will only show when you press the button.';

function chooseMode(mode) {
  showMsg('');
  if (mode === 'site') {
    if (!currentOrigin) return showMsg('Open the website first, then pick "This site".');
    const asked = allow([pattern(currentOrigin)]);
    save({ mode: 'site', siteOrigin: currentOrigin });
    asked.then((ok) => { if (!ok) showMsg(NO); });
  } else if (mode === 'all') {
    const asked = allow(['<all_urls>']);
    save({ mode: 'all' });
    asked.then((ok) => { if (!ok) showMsg(NO); });
  } else {
    save({ mode: 'list' });
  }
}

function addSite(origin) {
  if (!origin) return showMsg('That doesn\'t look like a website address.');
  showMsg('');
  const asked = allow([pattern(origin)]);
  const sites = [...new Set([...(settings.sites || []), origin])];
  save({ mode: 'list', sites });
  asked.then((ok) => { if (!ok) showMsg('The browser said no for that site, so the bar won\'t show there by itself.'); });
}

document.querySelectorAll('#mode button').forEach((b) => (b.onclick = () => chooseMode(b.dataset.v)));
document.querySelectorAll('#position button').forEach((b) => (b.onclick = async () => {
  await api.storage.local.remove('barPos');
  save({ position: b.dataset.v });
}));
document.querySelectorAll('#defaultType button').forEach((b) => (b.onclick = () => save({ defaultType: b.dataset.v })));
$('blurForms').onchange = (e) => save({ blurForms: e.target.checked });
$('addSite').onclick = () => { addSite(normalise($('siteInput').value)); $('siteInput').value = ''; };
$('siteInput').onkeydown = (e) => { if (e.key === 'Enter') $('addSite').click(); };
$('addCurrent').onclick = () => addSite(currentOrigin);

$('toggle').onclick = async () => {
  const r = await send({ cmd: 'toggleActive' });
  if (r && r.ok) window.close();
  else showMsg('The bar can\'t run on this page (browser pages and add-on stores are blocked). Try a normal website.');
};

/* ---------- cloud (Backblaze + GitHub) ---------- */

function setDot(id, on) {
  $(id).textContent = on ? '●' : '○';
  $(id).classList.toggle('on', on);
}

async function loadCloud() {
  const c = await send({ cmd: 'getCloud' });
  if (!c) return;
  // Pre-fill Ricky's usual Backblaze place so only the two keys need pasting.
  $('b2Endpoint').value = (c.b2 && c.b2.endpoint) || $('b2Endpoint').value || $('b2Endpoint').placeholder;
  $('b2Bucket').value = (c.b2 && c.b2.bucket) || $('b2Bucket').value || $('b2Bucket').placeholder;
  if (c.b2) {
    $('b2KeyId').value = c.b2.keyId || '';
    $('b2AppKey').placeholder = c.b2.hasKey ? '•••••••• (saved)' : 'K004…';
  }
  if (c.gh) {
    $('ghRepo').value = c.gh.repo || '';
    $('ghToken').placeholder = c.gh.hasKey ? '•••••••• (saved)' : 'github_pat_…';
  }
  renderLogin(c);
  setDot('b2Dot', !!(c.b2 && c.b2.hasKey));
  setDot('ghDot', !!(c.gh && c.gh.hasKey));
  $('cloudErr').textContent = c.error ? `⚠️ Last picture upload failed: ${c.error}` : '';
  $('cloudErr').classList.toggle('hidden', !c.error);
}

function result(el, r, okText) {
  $(el).innerHTML = '';
  const span = document.createElement('span');
  span.className = r && r.ok ? 'good' : 'bad';
  span.textContent = r && r.ok ? okText : `❌ ${(r && r.error) || 'Something went wrong'}`;
  $(el).appendChild(span);
}

$('b2Save').onclick = () => {
  let endpoint = $('b2Endpoint').value.trim();
  const missing = [['b2Endpoint', 'Endpoint'], ['b2Bucket', 'Bucket name'], ['b2KeyId', 'keyID']].filter(([id]) => !$(id).value.trim()).map(([, n]) => n);
  if (missing.length) return result('b2Msg', { ok: false, error: `Fill in: ${missing.join(', ')}` });
  // Ask the browser to allow Backblaze (straight from the click).
  const asked = allow(['https://*.backblazeb2.com/*']);
  const values = { endpoint, bucket: $('b2Bucket').value.trim(), keyId: $('b2KeyId').value.trim() };
  if ($('b2AppKey').value.trim()) values.appKey = $('b2AppKey').value.trim();
  $('b2Msg').textContent = 'Testing…';
  asked.then(async (ok) => {
    if (!ok) return result('b2Msg', { ok: false, error: 'The browser said no to Backblaze. Press Save again and choose Allow.' });
    const r = await send({ cmd: 'setCloud', which: 'b2', values });
    result('b2Msg', r, r && r.shared ? '✅ Connected, and shared to your other browsers through GitHub.' : '✅ Connected. Pictures will upload to Backblaze.');
    if (r && r.ok) { $('b2AppKey').value = ''; clearDraft('b2'); }
    loadCloud();
  });
};
$('ghSave').onclick = () => {
  const asked = allow(['https://api.github.com/*']);
  const values = { repo: $('ghRepo').value.trim().replace(/^https?:\/\/github\.com\//, '').replace(/\.git$/, '').replace(/\/$/, '') };
  if ($('ghToken').value.trim()) values.token = $('ghToken').value.trim();
  $('ghMsg').textContent = 'Testing…';
  asked.then(async (ok) => {
    if (!ok) return result('ghMsg', { ok: false, error: 'The browser said no to GitHub. Press Save again and choose Allow.' });
    const r = await send({ cmd: 'setCloud', which: 'gh', values });
    result('ghMsg', r, '✅ Connected. 📤 Send to Claude is in the Fix List.');
    if (r && r.ok) { $('ghToken').value = ''; clearDraft('gh'); }
    loadCloud();
  });
};
$('b2Forget').onclick = async () => { await send({ cmd: 'setCloud', which: 'b2', clear: true }); $('b2AppKey').value = ''; $('b2Msg').textContent = 'Forgotten.'; loadCloud(); };
$('ghForget').onclick = async () => { await send({ cmd: 'setCloud', which: 'gh', clear: true }); $('ghToken').value = ''; $('ghMsg').textContent = 'Forgotten.'; loadCloud(); };


/* ---------- Sign in with GitHub (one click per browser) ---------- */

let lastCloud = null;
function renderLogin(c) {
  lastCloud = c;
  $('oneClick').classList.toggle('hidden', !c.canLogin);
  const signedIn = !!(c.gh && c.gh.hasKey && c.gh.via === 'login');
  $('ghLogin').classList.toggle('hidden', signedIn);
  $('loginDone').classList.toggle('hidden', !signedIn);
  if (signedIn) {
    $('loginWho').textContent = `${c.gh.login || 'signed in'} · ${c.gh.repo}`;
    const b2 = c.b2 && c.b2.hasKey;
    $('loginB2').textContent = b2
      ? (c.b2From === 'github' ? '✅ Backblaze: brought from GitHub' : '✅ Backblaze: set up (shared to your other browsers)')
      : '○ Backblaze: not set up yet. Fill in the Backblaze box below once.';
    if (!b2) $('b2Box').open = true;
  }
}

function showLoginState(st) {
  const waiting = st && st.status === 'waiting' && st.expires > Date.now();
  $('loginWait').classList.toggle('hidden', !waiting);
  if (waiting) {
    $('loginCode').textContent = st.userCode;
    $('loginOpen').dataset.uri = st.uri;
    $('ghLogin').classList.add('hidden');
  }
  if (st && st.status === 'error') { $('loginMsg').innerHTML = ''; result('loginMsg', { ok: false, error: st.error }); }
  return waiting;
}

let loginTimer = null;
function watchLogin() {
  clearInterval(loginTimer);
  loginTimer = setInterval(async () => {
    const st = await send({ cmd: 'ghLoginState' });
    if (st && st.status === 'waiting') return;
    clearInterval(loginTimer);
    showLoginState(st);
    if (st && st.status === 'done') { $('loginMsg').textContent = ''; await loadCloud(); }
    else if (lastCloud) renderLogin(lastCloud);
  }, 2000);
}

$('ghLogin').onclick = () => {
  // Ask for GitHub + Backblaze in one go, straight from the click.
  const asked = allow(['https://github.com/*', 'https://api.github.com/*', 'https://*.backblazeb2.com/*']);
  $('loginMsg').textContent = 'Asking GitHub for a code…';
  asked.then(async (ok) => {
    if (!ok) return result('loginMsg', { ok: false, error: 'The browser said no. Press Sign in again and choose Allow.' });
    const r = await send({ cmd: 'ghLoginStart', repo: $('ghRepo').value.trim() || undefined });
    if (!r || !r.ok) return result('loginMsg', r);
    $('loginMsg').textContent = '';
    showLoginState({ status: 'waiting', userCode: r.userCode, uri: r.uri, expires: Date.now() + 600000 });
    watchLogin();
  });
};
$('loginOpen').onclick = async () => {
  const code = $('loginCode').textContent;
  try { await navigator.clipboard.writeText(code); } catch (e) { /* the code is on screen too */ }
  api.tabs.create({ url: $('loginOpen').dataset.uri || 'https://github.com/login/device' });
};
$('loginCancel').onclick = async () => {
  clearInterval(loginTimer);
  await send({ cmd: 'ghLoginCancel' });
  $('loginWait').classList.add('hidden');
  if (lastCloud) renderLogin(lastCloud);
};

/* Keep what's been typed if the popup closes (e.g. to go and copy the next key).
   Drafts live in storage.session (memory only, cleared when the browser closes). */
const DRAFT_IDS = ['b2Endpoint', 'b2Bucket', 'b2KeyId', 'b2AppKey', 'ghRepo', 'ghToken'];
const draftStore = api.storage.session || null;
function saveDraft() {
  if (!draftStore) return;
  const d = {};
  DRAFT_IDS.forEach((id) => { d[id] = $(id).value; });
  d.open = [...document.querySelectorAll('details')].filter((x) => x.open).map((x) => x.id);
  draftStore.set({ cloudDraft: d }).catch(() => {});
}
async function restoreDraft() {
  if (!draftStore) return;
  try {
    const { cloudDraft } = await draftStore.get('cloudDraft');
    if (!cloudDraft) return;
    DRAFT_IDS.forEach((id) => { if (cloudDraft[id]) $(id).value = cloudDraft[id]; });
    (cloudDraft.open || []).forEach((id) => { if ($(id)) $(id).open = true; });
  } catch (e) { /* ignore */ }
}
function clearDraft(prefix) {
  if (!draftStore) return;
  DRAFT_IDS.filter((id) => id.startsWith(prefix)).forEach((id) => { $(id).value = $(id).type === 'password' ? '' : $(id).value; });
  saveDraft();
}
DRAFT_IDS.forEach((id) => $(id).addEventListener('input', saveDraft));
document.querySelectorAll('details').forEach((d) => d.addEventListener('toggle', saveDraft));

(async () => {
  await loadCloud();
  const st = await send({ cmd: 'ghLoginState' });
  if (showLoginState(st)) watchLogin();
  else if (st && st.status === 'error') { /* shown */ }
  if (lastCloud && lastCloud.gh && lastCloud.gh.hasKey) send({ cmd: 'pullShared' }).then((r) => { if (r && r.found) loadCloud(); });
  await restoreDraft();
  settings = await send({ cmd: 'getSettings' });
  const t = await send({ cmd: 'activeTabUrl' });
  if (t && t.url && /^https?:/.test(t.url)) currentOrigin = new URL(t.url).origin;
  if (!currentOrigin) $('addCurrent').classList.add('hidden');
  const r = await send({ cmd: 'listFixes' });
  const n = r && r.fixes ? r.fixes.length : 0;
  $('count').textContent = `${n} fix${n === 1 ? '' : 'es'}`;
  const { syncFull } = await api.storage.local.get('syncFull');
  $('syncFull').classList.toggle('hidden', !syncFull);
  render();
})();
