/* Claude To Fix — optional cloud helpers.
 *  - Backblaze B2 (S3-compatible API, AWS Signature V4): stores fix pictures so every computer can see them.
 *  - GitHub (REST + Git Data API): "Send to Claude" commits fixes.md + fixes.json + pictures into a private repo.
 * Keys stay in this browser's storage.local and are only ever sent to Backblaze / GitHub. */
(function (g) {
  const enc = new TextEncoder();
  const hex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
  const toBytes = (d) => (typeof d === 'string' ? enc.encode(d) : d instanceof ArrayBuffer ? new Uint8Array(d) : d || new Uint8Array(0));

  async function sha256(data) {
    return crypto.subtle.digest('SHA-256', toBytes(data));
  }
  async function hmac(key, data) {
    const k = await crypto.subtle.importKey('raw', toBytes(key), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
    return crypto.subtle.sign('HMAC', k, enc.encode(data));
  }
  function uriEncode(s) {
    return encodeURIComponent(s).replace(/[!'()*]/g, (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase());
  }
  function b64(bytes) {
    bytes = toBytes(bytes);
    let s = '';
    for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return btoa(s);
  }

  /* ---------------- AWS Signature V4 (used by Backblaze's S3 API) ---------------- */

  async function signV4({ method, url, region, service = 's3', keyId, secret, body, headers = {}, now = new Date() }) {
    const u = new URL(url);
    const amzDate = now.toISOString().replace(/[:-]|\.\d{3}/g, '');
    const date = amzDate.slice(0, 8);
    const payloadHash = hex(await sha256(body || new Uint8Array(0)));
    const all = {};
    Object.keys(headers).forEach((k) => { all[k.toLowerCase()] = String(headers[k]).trim().replace(/\s+/g, ' '); });
    all.host = u.host;
    all['x-amz-date'] = amzDate;
    all['x-amz-content-sha256'] = payloadHash;
    const names = Object.keys(all).sort();
    const canonHeaders = names.map((n) => `${n}:${all[n]}\n`).join('');
    const signedHeaders = names.join(';');
    const path = u.pathname.split('/').map((seg) => uriEncode(decodeURIComponent(seg))).join('/') || '/';
    const qs = [...u.searchParams.entries()]
      .map(([k, v]) => [uriEncode(k), uriEncode(v)])
      .sort((a, b) => (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : a[1] < b[1] ? -1 : 1))
      .map(([k, v]) => `${k}=${v}`).join('&');
    const canonical = [method, path, qs, canonHeaders, signedHeaders, payloadHash].join('\n');
    const scope = `${date}/${region}/${service}/aws4_request`;
    const toSign = ['AWS4-HMAC-SHA256', amzDate, scope, hex(await sha256(canonical))].join('\n');
    let k = await hmac('AWS4' + secret, date);
    k = await hmac(k, region);
    k = await hmac(k, service);
    k = await hmac(k, 'aws4_request');
    const signature = hex(await hmac(k, toSign));
    const out = {};
    names.forEach((n) => { if (n !== 'host') out[n] = all[n]; });
    out.authorization = `AWS4-HMAC-SHA256 Credential=${keyId}/${scope}, SignedHeaders=${signedHeaders}, Signature=${signature}`;
    return out;
  }

  /* ---------------- Backblaze B2 ---------------- */

  // Accepts "s3.us-west-004.backblazeb2.com", "https://s3.us-west-004.backblazeb2.com/", or a test URL.
  function b2Origin(endpoint) {
    let e = String(endpoint || '').trim().replace(/\/+$/, '');
    if (!/^https?:\/\//i.test(e)) e = 'https://' + e;
    const u = new URL(e);
    const m = u.hostname.match(/^s3\.([a-z0-9-]+)\.backblazeb2\.com$/i);
    return { origin: u.origin, region: m ? m[1] : 'us-east-1' };
  }

  function b2Ready(cfg) {
    return !!(cfg && cfg.endpoint && cfg.bucket && cfg.keyId && cfg.appKey);
  }

  async function b2Request(cfg, method, key, body, contentType) {
    const { origin, region } = b2Origin(cfg.endpoint);
    const path = '/' + [cfg.bucket, ...key.split('/')].map(uriEncode).join('/');
    const url = origin + path;
    const headers = contentType ? { 'content-type': contentType } : {};
    const signed = await signV4({ method, url, region, keyId: cfg.keyId, secret: cfg.appKey, body, headers });
    const res = await fetch(url, { method, headers: signed, body: body || undefined });
    if (!res.ok && !(method === 'DELETE' && res.status === 404)) {
      const t = (await res.text().catch(() => '')).replace(/\s+/g, ' ');
      const code = (t.match(/<Code>([^<]+)<\/Code>/) || [])[1];
      const msg = (t.match(/<Message>([^<]+)<\/Message>/) || [])[1];
      const err = new Error(`Backblaze ${method} ${res.status}${code ? ' ' + code : ''}${msg ? ': ' + msg : ''}`);
      err.status = res.status;
      throw err;
    }
    return res;
  }

  const b2Put = (cfg, key, bytes, type) => b2Request(cfg, 'PUT', key, toBytes(bytes), type || 'application/octet-stream');
  const b2Delete = (cfg, key) => b2Request(cfg, 'DELETE', key);
  async function b2Get(cfg, key) {
    const res = await b2Request(cfg, 'GET', key);
    return new Uint8Array(await res.arrayBuffer());
  }

  async function b2Test(cfg) {
    const key = `claude-to-fix-test-${Date.now()}.txt`;
    await b2Put(cfg, key, 'Claude To Fix connection test', 'text/plain');
    const back = new TextDecoder().decode(await b2Get(cfg, key));
    await b2Delete(cfg, key);
    if (!back.startsWith('Claude To Fix')) throw new Error('Backblaze test file came back different');
    return { ok: true };
  }

  /* ---------------- GitHub ---------------- */

  function ghReady(cfg) {
    return !!(cfg && cfg.repo && cfg.token && /^[\w.-]+\/[\w.-]+$/.test(cfg.repo));
  }

  async function gh(cfg, method, path, body) {
    const res = await fetch((cfg.apiBase || 'https://api.github.com') + path, {
      cache: 'no-store',
      method,
      headers: Object.assign({
        Authorization: `Bearer ${cfg.token}`,
        Accept: 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28'
      }, body ? { 'Content-Type': 'application/json' } : {}),
      body: body ? JSON.stringify(body) : undefined
    });
    if (!res.ok) {
      let msg = '';
      try { msg = (await res.json()).message || ''; } catch (e) { /* ignore */ }
      const err = new Error(`GitHub ${res.status}${msg ? ': ' + msg : ''}`);
      err.status = res.status;
      throw err;
    }
    return res.status === 204 ? null : res.json();
  }

  const INBOX_README = `# Claude fix lists

Made by the **Claude To Fix** browser extension.

Each folder in \`inbox/\` is one fix list sent with **📤 Send to Claude**:

- \`fixes.md\`: read this first. One section per fix: note, page URL, CSS selector, styles, pictures.
- \`fixes.json\`: the same data in full.
- \`shots/NN-full.png\` and \`shots/NN-crop.png\`: screenshots. The red outline marks what was picked.

**For Claude:** work through the newest folder that has no \`DONE.md\`. When finished, add \`DONE.md\` to that folder listing what you changed for each fix number (and anything you skipped and why).
`;

  async function ghRepo(cfg) {
    const r = await gh(cfg, 'GET', `/repos/${cfg.repo}`);
    return { private: r.private, branch: r.default_branch || 'main', canPush: !r.permissions || r.permissions.push !== false };
  }

  async function ghHead(cfg, branch) {
    try {
      const ref = await gh(cfg, 'GET', `/repos/${cfg.repo}/git/ref/heads/${branch}`);
      return ref.object.sha;
    } catch (e) {
      if (e.status !== 409 && e.status !== 404) throw e;
      // Empty repo: make the first commit with a README that tells Claude how to use it.
      await gh(cfg, 'PUT', `/repos/${cfg.repo}/contents/README.md`, {
        message: 'Set up Claude fix inbox', content: b64(INBOX_README), branch
      });
      const ref = await gh(cfg, 'GET', `/repos/${cfg.repo}/git/ref/heads/${branch}`);
      return ref.object.sha;
    }
  }

  async function ghTest(cfg) {
    const info = await ghRepo(cfg);
    await ghHead(cfg, info.branch);
    return info;
  }

  /** files: [{ path, bytes }] — committed together in one commit. Returns the commit info. */
  async function ghCommit(cfg, files, message) {
    const info = await ghRepo(cfg);
    const branch = info.branch;
    for (let attempt = 0; attempt < 3; attempt++) {
      const head = await ghHead(cfg, branch);
      const commit = await gh(cfg, 'GET', `/repos/${cfg.repo}/git/commits/${head}`);
      const tree = [];
      for (const f of files) {
        if (!f.sha) f.sha = (await gh(cfg, 'POST', `/repos/${cfg.repo}/git/blobs`, { content: b64(f.bytes), encoding: 'base64' })).sha;
        tree.push({ path: f.path, mode: '100644', type: 'blob', sha: f.sha });
      }
      const t = await gh(cfg, 'POST', `/repos/${cfg.repo}/git/trees`, { base_tree: commit.tree.sha, tree });
      const c = await gh(cfg, 'POST', `/repos/${cfg.repo}/git/commits`, { message, tree: t.sha, parents: [head] });
      try {
        await gh(cfg, 'PATCH', `/repos/${cfg.repo}/git/refs/heads/${branch}`, { sha: c.sha });
        return { branch, commit: c.sha };
      } catch (e) {
        if (e.status !== 422 || attempt === 2) throw e; // someone else pushed at the same moment: try again
      }
    }
    throw new Error('GitHub: could not save');
  }


  /* ---------------- GitHub sign-in (device flow) ----------------
   * "Sign in with GitHub": GitHub shows a short code, the person types it on
   * github.com/login/device, and we get a token for the Claude To Fix GitHub App
   * (only the repos the app is installed on, Contents read/write). No secret needed. */

  async function ghForm(url, params) {
    const res = await fetch(url, {
      method: 'POST',
      headers: { Accept: 'application/json', 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams(params).toString()
    });
    let j = null;
    try { j = await res.json(); } catch (e) { j = null; }
    if (!res.ok || !j) throw new Error(`GitHub sign-in ${res.status}`);
    return j;
  }

  async function ghDeviceStart(clientId, base) {
    const j = await ghForm((base || 'https://github.com') + '/login/device/code', { client_id: clientId });
    if (j.error) throw new Error(j.error_description || j.error);
    return { deviceCode: j.device_code, userCode: j.user_code, uri: j.verification_uri, interval: j.interval || 5, expiresIn: j.expires_in || 900 };
  }

  /** Returns { token } when done, { wait: seconds } to keep waiting, or throws. */
  async function ghDevicePoll(clientId, deviceCode, base) {
    const j = await ghForm((base || 'https://github.com') + '/login/oauth/access_token', {
      client_id: clientId, device_code: deviceCode, grant_type: 'urn:ietf:params:oauth:grant-type:device_code'
    });
    if (j.access_token) return { token: j.access_token };
    if (j.error === 'authorization_pending') return { wait: 0 };
    if (j.error === 'slow_down') return { wait: j.interval || 10 };
    if (j.error === 'expired_token') throw new Error('The code ran out of time. Press Sign in again.');
    if (j.error === 'access_denied') throw new Error('Sign-in was cancelled on GitHub.');
    throw new Error(j.error_description || j.error || 'GitHub sign-in failed');
  }

  async function ghUser(cfg) {
    const u = await gh(cfg, 'GET', '/user');
    return u.login;
  }

  /** Text of a file in the repo, or null if it isn't there. */
  async function ghReadFile(cfg, path) {
    try {
      const f = await gh(cfg, 'GET', `/repos/${cfg.repo}/contents/${path}`);
      const bin = atob(String(f.content || '').replace(/\s/g, ''));
      return new TextDecoder().decode(Uint8Array.from(bin, (c) => c.charCodeAt(0)));
    } catch (e) {
      if (e.status === 404) return null;
      throw e;
    }
  }

  g.CTFCloud = { signV4, b2Ready, b2Put, b2Get, b2Delete, b2Test, b2Origin, ghReady, ghTest, ghCommit, ghDeviceStart, ghDevicePoll, ghUser, ghReadFile, b64 };
})(globalThis);
