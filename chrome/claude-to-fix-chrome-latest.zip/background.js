/* Claude To Fix — background (service worker in Chromium, event page in Firefox).
 * Owns: fix list (storage.local), screenshots (IndexedDB), capture + crop,
 * fixes.md + zip building, downloads, auto-show registration.
 * Network: only to Backblaze (pictures) and GitHub (Send to Claude), and only
 * when the person has added their own keys in the popup. */

if (typeof CTFCloud === 'undefined' && typeof importScripts === 'function') importScripts('cloud.js');
const api = globalThis.browser && globalThis.browser.runtime ? globalThis.browser : globalThis.chrome;

const DEFAULT_SETTINGS = {
  mode: null,            // null = only via icon/shortcut, 'site' = siteOrigin, 'list' = sites[], 'all'
  siteOrigin: null,
  sites: [],
  position: 'top-center', // 'top-center' | 'top-right' | 'bottom-right'
  defaultType: 'Style',
  blurForms: true
};

/* ---------------- storage helpers ---------------- */

async function getSettings() {
  const { settings } = await api.storage.local.get('settings');
  return Object.assign({}, DEFAULT_SETTINGS, settings || {});
}

/* ---------------- fix list + browser sync ----------------
 * storage.local holds the full list on this computer.
 * storage.sync (Firefox Sync / Chrome sign-in) holds a copy of each fix's text
 * (note, page, selector, styles) so the list follows you to other computers.
 * Pictures never go to sync; they stay in this computer's IndexedDB.
 * Sync limits: ~100 KB total, 8 KB per fix, so roughly 40 fixes. */

const SYNC_ORDER = 'ctf_order';
const SYNC_PREFIX = 'ctf_fix_';
const SYNC_ITEM_MAX = 7800;
const hasSync = () => !!(api.storage && api.storage.sync);
const enc = new TextEncoder();
const jsonSize = (k, v) => enc.encode(k + JSON.stringify(v)).length;

async function deviceId() {
  const { deviceId: id } = await api.storage.local.get('deviceId');
  if (id) return id;
  const nid = Math.random().toString(36).slice(2, 10);
  await api.storage.local.set({ deviceId: nid });
  return nid;
}

function compact(f) {
  const c = JSON.parse(JSON.stringify(f));
  delete c.hasFull; delete c.hasCrop; delete c.synced;
  const k = SYNC_PREFIX + f.id;
  if (jsonSize(k, c) > SYNC_ITEM_MAX && c.inside) c.inside = c.inside.slice(0, 3);
  if (jsonSize(k, c) > SYNC_ITEM_MAX && c.element) { delete c.element.data; delete c.element.attrs; delete c.element.classes; }
  if (jsonSize(k, c) > SYNC_ITEM_MAX && c.element) delete c.element.styles;
  if (jsonSize(k, c) > SYNC_ITEM_MAX) c.note = String(c.note || '').slice(0, 3000);
  return c;
}

async function readSync() {
  if (!hasSync()) return null;
  try { return await api.storage.sync.get(null); } catch (e) { return null; }
}

/** Copy the list to storage.sync. Returns the ids that made it into sync. */
async function pushSync(fixes) {
  if (!hasSync()) return null;
  const cur = (await readSync()) || {};
  const keep = new Set(fixes.map((f) => SYNC_PREFIX + f.id));
  const stale = Object.keys(cur).filter((k) => k.startsWith(SYNC_PREFIX) && !keep.has(k));
  try { if (stale.length) await api.storage.sync.remove(stale); } catch (e) { /* ignore */ }
  const saved = [];
  let full = false;
  for (const f of fixes) {
    const k = SYNC_PREFIX + f.id;
    const v = compact(f);
    if (JSON.stringify(cur[k]) === JSON.stringify(v)) { saved.push(f.id); continue; }
    if (full) continue;
    try { await api.storage.sync.set({ [k]: v }); saved.push(f.id); }
    catch (e) { full = true; console.warn('Claude To Fix: sync is full', e); }
  }
  try {
    if (JSON.stringify(cur[SYNC_ORDER]) !== JSON.stringify(saved)) await api.storage.sync.set({ [SYNC_ORDER]: saved });
  } catch (e) { full = true; }
  await api.storage.local.set({ syncFull: full });
  return saved;
}

/** Merge this computer's list with what sync holds (other computers' changes). */
async function getFixes() {
  const { fixes } = await api.storage.local.get('fixes');
  const local = Array.isArray(fixes) ? fixes : [];
  const s = await readSync();
  if (!s || !Array.isArray(s[SYNC_ORDER])) return local;
  const byLocal = new Map(local.map((f) => [f.id, f]));
  const out = [];
  for (const id of s[SYNC_ORDER]) {
    const r = s[SYNC_PREFIX + id];
    const l = byLocal.get(id);
    if (!r && !l) continue;
    let f;
    if (l && (!r || (l.updated || l.time || 0) >= (r.updated || r.time || 0))) f = Object.assign({}, l);
    else f = Object.assign({}, r, { hasFull: l ? !!l.hasFull : false, hasCrop: l ? !!l.hasCrop : false });
    f.synced = true;
    out.push(f);
    byLocal.delete(id);
  }
  const removed = [];
  for (const f of byLocal.values()) {
    if (f.synced) removed.push(f.id);   // was synced, now gone: deleted on another computer
    else out.push(f);                   // not synced yet (new here, or sync full)
  }
  if (JSON.stringify(out) !== JSON.stringify(local)) {
    await api.storage.local.set({ fixes: out });
    removed.forEach((id) => delShots(id).catch(() => {}));
  }
  return out;
}

async function setFixes(fixes) {
  await api.storage.local.set({ fixes });
  const saved = await pushSync(fixes);
  if (saved) {
    const ok = new Set(saved);
    const marked = fixes.map((f) => Object.assign({}, f, { synced: ok.has(f.id) }));
    await api.storage.local.set({ fixes: marked });
  }
}

// Another computer changed the list: merge it in (content scripts see the storage.local change).
let syncTimer = null;
api.storage.onChanged.addListener((changes, area) => {
  if (area !== 'sync') return;
  clearTimeout(syncTimer);
  syncTimer = setTimeout(() => { queue(() => getFixes()).catch(() => {}); }, 400);
});

// One change at a time, so two quick edits can't overwrite each other.
let chain = Promise.resolve();
function queue(fn) {
  const p = chain.then(fn, fn);
  chain = p.catch(() => {});
  return p;
}

/* ---------------- IndexedDB for screenshots ---------------- */

let dbPromise = null;
function db() {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open('claude-to-fix', 1);
      req.onupgradeneeded = () => req.result.createObjectStore('shots');
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => { dbPromise = null; reject(req.error); };
    });
  }
  return dbPromise;
}

async function idb(mode, fn) {
  const d = await db();
  return new Promise((resolve, reject) => {
    const tx = d.transaction('shots', mode);
    const store = tx.objectStore('shots');
    const req = fn(store);
    tx.oncomplete = () => resolve(req && req.result);
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
}

const putShots = (id, shots) => idb('readwrite', (s) => s.put(shots, id));
const getShots = (id) => idb('readonly', (s) => s.get(id));
const delShots = (id) => idb('readwrite', (s) => s.delete(id));
const clearShots = () => idb('readwrite', (s) => s.clear());

/* ---------------- image helpers ---------------- */

function dataUrlToBlob(dataUrl) {
  const [head, b64] = dataUrl.split(',');
  const mime = (head.match(/data:([^;]+)/) || [])[1] || 'image/png';
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new Blob([bytes], { type: mime });
}

function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = () => reject(r.error);
    r.readAsDataURL(blob);
  });
}

function roundRect(ctx, x, y, w, h, r) {
  r = Math.max(0, Math.min(r, w / 2, h / 2));
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function drawOutline(ctx, rect, scale, offX, offY) {
  const lw = Math.max(2, Math.round(3 * scale));
  ctx.save();
  ctx.strokeStyle = '#ff2d2d';
  ctx.lineWidth = lw;
  ctx.shadowColor = 'rgba(0,0,0,0.45)';
  ctx.shadowBlur = 4 * scale;
  roundRect(ctx,
    rect.x * scale - offX - lw / 2,
    rect.y * scale - offY - lw / 2,
    rect.w * scale + lw,
    rect.h * scale + lw,
    4 * scale);
  ctx.stroke();
  ctx.restore();
}

/** Takes the visible-tab PNG and returns { full, crop } Blobs with the red outline drawn. */
async function makeShots(pngDataUrl, rect, viewport) {
  const srcBlob = dataUrlToBlob(pngDataUrl);
  const bmp = await createImageBitmap(srcBlob);
  const scale = bmp.width / Math.max(1, viewport.w);

  // Full shot with outline.
  const fullC = new OffscreenCanvas(bmp.width, bmp.height);
  const fctx = fullC.getContext('2d');
  fctx.drawImage(bmp, 0, 0);
  if (rect) drawOutline(fctx, rect, scale, 0, 0);
  const full = await fullC.convertToBlob({ type: 'image/png' });

  // Crop around the pick (60 CSS px padding), clamped to the image.
  let crop = null;
  if (rect) {
    const pad = 60;
    const x0 = Math.max(0, Math.floor((rect.x - pad) * scale));
    const y0 = Math.max(0, Math.floor((rect.y - pad) * scale));
    const x1 = Math.min(bmp.width, Math.ceil((rect.x + rect.w + pad) * scale));
    const y1 = Math.min(bmp.height, Math.ceil((rect.y + rect.h + pad) * scale));
    const cw = Math.max(1, x1 - x0);
    const ch = Math.max(1, y1 - y0);
    const cropC = new OffscreenCanvas(cw, ch);
    const cctx = cropC.getContext('2d');
    cctx.drawImage(bmp, x0, y0, cw, ch, 0, 0, cw, ch);
    drawOutline(cctx, rect, scale, x0, y0);
    crop = await cropC.convertToBlob({ type: 'image/png' });
  }
  bmp.close && bmp.close();
  return { full, crop };
}

/* ---------------- fixes.md ---------------- */

const pad2 = (n) => String(n).padStart(2, '0');
function stamp(d, sep = ' ', colon = ':') {
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}${sep}${pad2(d.getHours())}${colon}${pad2(d.getMinutes())}`;
}

function hostOf(url) {
  try { return new URL(url).host; } catch (e) { return url || '?'; }
}

function mostCommon(values) {
  const m = new Map();
  values.forEach((v) => m.set(v, (m.get(v) || 0) + 1));
  let best = null, n = -1;
  m.forEach((c, v) => { if (c > n) { best = v; n = c; } });
  return { value: best, all: m.size === 1 };
}

const screenLabel = (f) => (f.screen ? `${f.screen.w}×${f.screen.h}` : '?');
const themeLabel = (f) => (f.theme && f.theme.label) || 'Light';

function shotName(i, kind) {
  return `shots/${pad2(i + 1)}-${kind}.png`;
}

function buildMarkdown(fixes, withPictures = true, here = null) {
  const now = new Date();
  const hosts = [...new Set(fixes.map((f) => hostOf(f.url)))];
  const scr = mostCommon(fixes.map(screenLabel));
  const thm = mostCommon(fixes.map(themeLabel));
  const lines = [];
  lines.push(`# Claude Fix List — ${stamp(now)}`);
  lines.push(`Site: ${hosts.join(', ') || '—'} · ${fixes.length} fix${fixes.length === 1 ? '' : 'es'} · Screen ${scr.value || '?'} · ${thm.value || 'Light'} mode`);
  lines.push('');
  lines.push('> Made with the Claude To Fix browser extension. Each fix below is one change the reviewer wants.');
  lines.push('> Open the Page, find the element with Selector (or Picked + text), look at the Pictures, then make the change in the Note.');
  if (withPictures) lines.push('> Pictures are in the shots/ folder next to this file. The red outline marks the picked part. fixes.json has the same data in full.');
  lines.push('');

  fixes.forEach((f, i) => {
    const el = f.element || {};
    const st = el.styles || {};
    lines.push(`## ${i + 1}. ${f.type || 'Style'} — ${f.pageName || f.title || hostOf(f.url)}`);
    const noteLines = String(f.note || '').trim().split(/\r?\n/);
    lines.push(`Note: ${noteLines[0] || ''}`);
    noteLines.slice(1).forEach((l) => lines.push(`      ${l}`));
    lines.push(`Page: ${f.url}`);
    if (f.area) lines.push(`Picked: an area ${Math.round(f.rect.w)}×${Math.round(f.rect.h)} at x ${Math.round(f.rect.x)}, y ${Math.round(f.rect.y)} (page scrolled ${f.scroll ? f.scroll.x + ',' + f.scroll.y : '0,0'})${el.short ? ` · centre element ${el.short}${el.text ? `  "${el.text.slice(0, 60)}"` : ''}` : ''}`);
    else lines.push(`Picked: ${el.short || '?'}${el.text ? `  "${el.text}"` : ''}`);
    if (el.selector) lines.push(`Selector: ${el.selector}`);
    if (f.area && f.inside && f.inside.length) lines.push(`Inside: ${f.inside.map((x) => `${x.short}${x.text ? ` "${x.text}"` : ''}`).join(' · ')}`);
    const attrs = [];
    if (el.id) attrs.push(`id="${el.id}"`);
    Object.entries(el.data || {}).forEach(([k, v]) => attrs.push(`${k}="${v}"`));
    Object.entries(el.attrs || {}).forEach(([k, v]) => attrs.push(`${k}="${v}"`));
    if (attrs.length) lines.push(`Attributes: ${attrs.join(' · ')}`);
    const sp = [];
    if (st.fontSize) sp.push(`font-size ${st.fontSize}`);
    if (st.fontWeight) sp.push(`weight ${st.fontWeight}`);
    if (st.color) sp.push(`colour ${st.color}`);
    if (st.background) sp.push(`bg ${st.background}${st.effectiveBackground && st.effectiveBackground !== st.background ? ` (shows ${st.effectiveBackground})` : ''}`);
    if (st.borderRadius && st.borderRadius !== '0px') sp.push(`radius ${st.borderRadius}`);
    if (st.padding) sp.push(`padding ${st.padding}`);
    if (st.margin && st.margin !== '0px') sp.push(`margin ${st.margin}`);
    if (st.fontFamily) sp.push(`font ${st.fontFamily}`);
    if (sp.length) lines.push(`Styles: ${sp.join(' · ')}`);
    if (f.rect) lines.push(`Box: ${Math.round(f.rect.w)}×${Math.round(f.rect.h)} at x ${Math.round(f.rect.x)}, y ${Math.round(f.rect.y)} in a ${f.viewport ? f.viewport.w + '×' + f.viewport.h : '?'} window${st.width ? ` · css width ${st.width} · height ${st.height}` : ''}`);
    if (el.parents && el.parents.length) lines.push(`Parents: ${el.parents.join(' > ')}`);
    if (!scr.all || !thm.all) lines.push(`Screen: ${screenLabel(f)} · ${themeLabel(f)} mode`);
    if (withPictures) {
      const pics = [];
      if (f.hasFull) pics.push(shotName(i, 'full'));
      if (f.hasCrop) pics.push(shotName(i, 'crop'));
      const elsewhere = !pics.length && f.device && here && f.device !== here;
      lines.push(`Pictures: ${pics.length ? pics.join(', ') : elsewhere ? 'none (made on another computer; pictures stay there)' : 'none'}`);
    }
    lines.push(`Time: ${f.time ? stamp(new Date(f.time)) : '?'}`);
    lines.push('');
  });
  return lines.join('\n');
}

/* ---------------- zip (store, no compression; PNGs are already compressed) ---------------- */

const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();

function crc32(bytes) {
  let c = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function makeZip(files) {
  // files: [{ name, data: Uint8Array }]
  const enc = new TextEncoder();
  const now = new Date();
  const dosTime = (now.getHours() << 11) | (now.getMinutes() << 5) | (Math.floor(now.getSeconds() / 2));
  const dosDate = ((now.getFullYear() - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate();
  const parts = [];
  const central = [];
  let offset = 0;

  for (const f of files) {
    const name = enc.encode(f.name);
    const crc = crc32(f.data);
    const size = f.data.length;
    const lh = new DataView(new ArrayBuffer(30));
    lh.setUint32(0, 0x04034b50, true);
    lh.setUint16(4, 20, true);
    lh.setUint16(6, 0x0800, true); // UTF-8 names
    lh.setUint16(8, 0, true);      // store
    lh.setUint16(10, dosTime, true);
    lh.setUint16(12, dosDate, true);
    lh.setUint32(14, crc, true);
    lh.setUint32(18, size, true);
    lh.setUint32(22, size, true);
    lh.setUint16(26, name.length, true);
    lh.setUint16(28, 0, true);
    parts.push(new Uint8Array(lh.buffer), name, f.data);

    const ch = new DataView(new ArrayBuffer(46));
    ch.setUint32(0, 0x02014b50, true);
    ch.setUint16(4, 20, true);
    ch.setUint16(6, 20, true);
    ch.setUint16(8, 0x0800, true);
    ch.setUint16(10, 0, true);
    ch.setUint16(12, dosTime, true);
    ch.setUint16(14, dosDate, true);
    ch.setUint32(16, crc, true);
    ch.setUint32(20, size, true);
    ch.setUint32(24, size, true);
    ch.setUint16(28, name.length, true);
    ch.setUint16(30, 0, true);
    ch.setUint16(32, 0, true);
    ch.setUint16(34, 0, true);
    ch.setUint16(36, 0, true);
    ch.setUint32(38, 0, true);
    ch.setUint32(42, offset, true);
    central.push(new Uint8Array(ch.buffer), name);
    offset += 30 + name.length + size;
  }

  const centralSize = central.reduce((n, p) => n + p.length, 0);
  const end = new DataView(new ArrayBuffer(22));
  end.setUint32(0, 0x06054b50, true);
  end.setUint16(8, files.length, true);
  end.setUint16(10, files.length, true);
  end.setUint32(12, centralSize, true);
  end.setUint32(16, offset, true);
  return new Blob([...parts, ...central, new Uint8Array(end.buffer)], { type: 'application/zip' });
}

/* ---------------- cloud: Backblaze pictures + GitHub inbox ---------------- */

async function getCloud() {
  const { cloud } = await api.storage.local.get('cloud');
  return Object.assign({ b2: null, gh: null }, cloud || {});
}
const picKey = (id, kind) => `pictures/${id}-${kind}.png`;

/** This computer's pictures for a fix, or download them from Backblaze if they were taken elsewhere. */
async function getShotsAny(fix) {
  let shots = null;
  try { shots = await getShots(fix.id); } catch (e) { shots = null; }
  if (shots && (shots.full || shots.crop)) return shots;
  if (!fix.cloud) return shots;
  const { b2 } = await getCloud();
  if (!CTFCloud.b2Ready(b2)) return shots;
  const got = {};
  for (const kind of ['full', 'crop']) {
    try { got[kind] = new Blob([await CTFCloud.b2Get(b2, picKey(fix.id, kind))], { type: 'image/png' }); } catch (e) { got[kind] = null; }
  }
  if (got.full || got.crop) {
    try { await putShots(fix.id, got); } catch (e) { /* ignore */ }
    return got;
  }
  return shots;
}

let uploading = false;
/** Upload any pictures not yet in Backblaze, then mark those fixes (the mark syncs to other computers). */
async function uploadPending() {
  if (uploading) return;
  uploading = true;
  try {
    const { b2 } = await getCloud();
    if (!CTFCloud.b2Ready(b2)) return;
    const fixes = await queue(() => getFixes());
    const done = [];
    for (const f of fixes) {
      if (f.cloud) continue;
      let shots = null;
      try { shots = await getShots(f.id); } catch (e) { shots = null; }
      if (!shots || (!shots.full && !shots.crop)) continue;
      try {
        if (shots.full) await CTFCloud.b2Put(b2, picKey(f.id, 'full'), await shots.full.arrayBuffer(), 'image/png');
        if (shots.crop) await CTFCloud.b2Put(b2, picKey(f.id, 'crop'), await shots.crop.arrayBuffer(), 'image/png');
        done.push(f.id);
      } catch (e) {
        console.warn('Claude To Fix: picture upload failed', e);
        await api.storage.local.set({ cloudError: String(e.message || e) });
        break;
      }
    }
    if (done.length) {
      await api.storage.local.set({ cloudError: null });
      await queue(async () => {
        const list = await getFixes();
        list.forEach((f) => { if (done.includes(f.id)) { f.cloud = true; f.updated = Date.now(); } });
        await setFixes(list);
      });
    }
  } finally {
    uploading = false;
  }
}

function deleteCloudPictures(fixes) {
  getCloud().then(({ b2 }) => {
    if (!CTFCloud.b2Ready(b2)) return;
    fixes.filter((f) => f && f.cloud).forEach((f) => {
      ['full', 'crop'].forEach((kind) => CTFCloud.b2Delete(b2, picKey(f.id, kind)).catch(() => {}));
    });
  });
}


/* ---------------- one-click setup: Sign in with GitHub ----------------
 * The person signs in with GitHub once per browser. The extension then reads the
 * shared settings file from their private repo (Backblaze details live there), so
 * no keys are pasted. The first time Backblaze is set up by hand, its details are
 * written to that file so every other browser picks them up. */

const GH_APP_CLIENT_ID = 'Iv23liauPCTdFpPNQjqW'; // public id of the "Claude To Fix" GitHub App (not a secret)
const DEFAULT_REPO = 'rickyluong/claude-fixes';
const SHARED_PATH = '.claude-to-fix/settings.json';

async function bases() {
  const { testBases } = await api.storage.local.get('testBases'); // only set by the automated tests
  return Object.assign({ login: 'https://github.com', api: undefined }, testBases || {});
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Only the extension's own settings screen may change keys. (On Android it opens as a tab, so check the address, not the tab.) */
function fromPopup(sender) {
  if (!sender || (!sender.id && !sender.url && !sender.tab)) return true; // called from inside the background itself
  const own = api.runtime.getURL('popup/popup.html');
  return sender.id === api.runtime.id && typeof sender.url === 'string' && sender.url.startsWith(own);
}

async function setLogin(state) {
  await api.storage.local.set({ ghLogin: state });
  return state;
}

async function ghLoginStart(repo) {
  if (!GH_APP_CLIENT_ID) return { ok: false, error: 'Sign in with GitHub isn\'t switched on in this version yet.' };
  const b = await bases();
  const d = await CTFCloud.ghDeviceStart(GH_APP_CLIENT_ID, b.login);
  const run = Date.now();
  await setLogin({ status: 'waiting', userCode: d.userCode, uri: d.uri, expires: run + d.expiresIn * 1000, run, repo: repo || DEFAULT_REPO });
  ghLoginWait(d, run, b, repo || DEFAULT_REPO); // keeps going after the popup closes
  return { ok: true, userCode: d.userCode, uri: d.uri };
}

async function ghLoginWait(d, run, b, repo) {
  let interval = d.interval;
  const end = Date.now() + d.expiresIn * 1000;
  try {
    while (Date.now() < end) {
      await sleep(interval * 1000);
      const { ghLogin } = await api.storage.local.get('ghLogin'); // also keeps the worker awake
      if (!ghLogin || ghLogin.run !== run || ghLogin.status !== 'waiting') return; // replaced or cancelled
      const r = await CTFCloud.ghDevicePoll(GH_APP_CLIENT_ID, d.deviceCode, b.login);
      if (r.wait) interval = Math.max(interval, r.wait);
      if (!r.token) continue;
      const cfg = { repo, token: r.token, apiBase: b.api, via: 'login' };
      cfg.login = await CTFCloud.ghUser(cfg);
      try { await CTFCloud.ghTest(cfg); }
      catch (e) {
        if (e.status === 404 || e.status === 403) throw new Error(`Signed in as ${cfg.login}, but the Claude To Fix app can't open ${repo}. On GitHub: Settings → Applications → Claude To Fix → Configure → add ${repo.split('/')[1]}.`);
        throw e;
      }
      const c = await getCloud();
      c.gh = cfg;
      await api.storage.local.set({ cloud: c });
      const shared = await pullShared();
      if (!shared && CTFCloud.b2Ready(c.b2)) await pushShared();
      await setLogin({ status: 'done', login: cfg.login, run, b2: shared ? 'pulled' : null });
      flashBadge();
      return;
    }
    await setLogin({ status: 'error', run, error: 'The code ran out of time. Press Sign in again.' });
  } catch (e) {
    await setLogin({ status: 'error', run, error: String(e && e.message || e) });
  }
}

function flashBadge() {
  try {
    api.action.setBadgeBackgroundColor({ color: '#2e7d32' });
    api.action.setBadgeText({ text: '✓' });
    setTimeout(() => api.action.setBadgeText({ text: '' }), 15000);
  } catch (e) { /* ignore */ }
}

/** Read the shared settings from the repo and use its Backblaze details here. Returns true if found. */
async function pullShared() {
  const c = await getCloud();
  if (!CTFCloud.ghReady(c.gh)) return false;
  let text = null;
  try { text = await CTFCloud.ghReadFile(c.gh, SHARED_PATH); } catch (e) { return false; }
  if (!text) return false;
  let data = null;
  try { data = JSON.parse(text); } catch (e) { return false; }
  const b2 = data && data.backblaze;
  if (!CTFCloud.b2Ready(b2)) return false;
  const next = { endpoint: b2.endpoint, bucket: b2.bucket, keyId: b2.keyId, appKey: b2.appKey, region: b2.region };
  Object.keys(next).forEach((k) => next[k] === undefined && delete next[k]);
  const same = c.b2 && ['endpoint', 'bucket', 'keyId', 'appKey'].every((k) => c.b2[k] === next[k]);
  if (!same) {
    c.b2 = Object.assign({}, c.b2 || {}, next, { from: 'github' });
    await api.storage.local.set({ cloud: c, cloudError: null });
    setTimeout(() => uploadPending(), 0);
  }
  return true;
}

/** Save this browser's Backblaze details to the repo, for the other browsers. */
async function pushShared() {
  const c = await getCloud();
  if (!CTFCloud.ghReady(c.gh) || !CTFCloud.b2Ready(c.b2)) return false;
  const body = {
    note: 'Made by the Claude To Fix extension. Every browser that signs in with GitHub reads Backblaze from here. Keep this repo private.',
    updated: new Date().toISOString(),
    backblaze: { endpoint: c.b2.endpoint, bucket: c.b2.bucket, keyId: c.b2.keyId, appKey: c.b2.appKey }
  };
  if (c.b2.region) body.backblaze.region = c.b2.region;
  await CTFCloud.ghCommit(c.gh, [{ path: SHARED_PATH, bytes: new TextEncoder().encode(JSON.stringify(body, null, 2) + '\n') }], 'Claude To Fix: shared settings');
  return true;
}

/** Everything that goes in a fix list: fixes.md, fixes.json, shots/NN-*.png */
async function collectFiles() {
  const fixes = await getFixes();
  const enc = new TextEncoder();
  const files = [];
  const full = fixes.map((f) => Object.assign({}, f));
  for (let i = 0; i < fixes.length; i++) {
    const shots = await getShotsAny(fixes[i]);
    full[i].hasFull = !!(shots && shots.full);
    full[i].hasCrop = !!(shots && shots.crop);
    if (shots && shots.full) files.push({ name: shotName(i, 'full'), data: new Uint8Array(await shots.full.arrayBuffer()) });
    if (shots && shots.crop) files.push({ name: shotName(i, 'crop'), data: new Uint8Array(await shots.crop.arrayBuffer()) });
  }
  const md = buildMarkdown(full, true, await deviceId());
  const json = JSON.stringify({
    tool: 'Claude To Fix', version: api.runtime.getManifest().version, made: new Date().toISOString(),
    fixes: full.map((f, i) => Object.assign({ number: i + 1 }, f, {
      pictures: [f.hasFull && shotName(i, 'full'), f.hasCrop && shotName(i, 'crop')].filter(Boolean)
    }))
  }, null, 2);
  files.unshift({ name: 'fixes.json', data: enc.encode(json) });
  files.unshift({ name: 'fixes.md', data: enc.encode(md) });
  return { files, fixes: full };
}

async function buildZip() {
  return makeZip((await collectFiles()).files);
}

async function sendToClaude() {
  const { gh } = await getCloud();
  if (!CTFCloud.ghReady(gh)) return { ok: false, error: 'Add your GitHub repo and key in the extension settings first.' };
  const { files, fixes } = await collectFiles();
  if (!fixes.length) return { ok: false, error: 'The list is empty.' };
  const hosts = [...new Set(fixes.map((f) => hostOf(f.url)))];
  const folder = `inbox/${stamp(new Date(), '-', '')}-${hosts[0] || 'site'}`.replace(/[^\w./-]/g, '-');
  const res = await CTFCloud.ghCommit(gh,
    files.map((f) => ({ path: `${folder}/${f.name}`, bytes: f.data })),
    `Fix list: ${fixes.length} fix${fixes.length === 1 ? '' : 'es'} on ${hosts.join(', ')}`);
  const url = `https://github.com/${gh.repo}/tree/${res.branch}/${folder}`;
  const message = `Please do the fixes in ${gh.repo}, folder ${folder} (read fixes.md first, pictures are in shots/).`;
  return { ok: true, folder, url, message, count: fixes.length };
}

async function downloadBlob(blob, filename) {
  let url;
  let revoke = null;
  if (typeof URL.createObjectURL === 'function') {
    url = URL.createObjectURL(blob);         // Firefox event page
    revoke = () => URL.revokeObjectURL(url);
  } else {
    url = await blobToDataUrl(blob);         // Chromium service worker
  }
  const id = await api.downloads.download({ url, filename, saveAs: false, conflictAction: 'uniquify' });
  if (revoke) setTimeout(revoke, 60000);
  return id;
}

/* ---------------- injection + auto-show ---------------- */

async function inject(tabId) {
  await api.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
}

async function sendToTab(tabId, msg) {
  try { return await api.tabs.sendMessage(tabId, msg); } catch (e) { return null; }
}

async function toggleBar(tabId) {
  await inject(tabId);
  return sendToTab(tabId, { cmd: 'toggle' });
}

function originPattern(origin) {
  try {
    const u = new URL(origin);
    return `${u.protocol}//${u.hostname}/*`;
  } catch (e) { return null; }
}

async function autoPatterns() {
  const s = await getSettings();
  let pats = [];
  if (s.mode === 'all') pats = ['<all_urls>'];
  else if (s.mode === 'site' && s.siteOrigin) pats = [originPattern(s.siteOrigin)];
  else if (s.mode === 'list') pats = (s.sites || []).map(originPattern);
  pats = pats.filter(Boolean);
  const granted = [];
  for (const p of pats) {
    try { if (await api.permissions.contains({ origins: [p] })) granted.push(p); } catch (e) { /* ignore */ }
  }
  return granted;
}

async function syncAutoScripts() {
  try {
    const existing = await api.scripting.getRegisteredContentScripts({ ids: ['ctf-auto'] });
    if (existing && existing.length) await api.scripting.unregisterContentScripts({ ids: ['ctf-auto'] });
  } catch (e) { /* ignore */ }
  const matches = await autoPatterns();
  if (!matches.length) return;
  try {
    await api.scripting.registerContentScripts([{
      id: 'ctf-auto', matches, js: ['content.js'], runAt: 'document_idle', persistAcrossSessions: true
    }]);
  } catch (e) { console.warn('Claude To Fix: could not register auto-show', e); }
}

async function shouldAutoShow(url) {
  const s = await getSettings();
  let origin;
  try { origin = new URL(url).origin; } catch (e) { return false; }
  const host = new URL(url).hostname;
  const sameHost = (o) => { try { return new URL(o).hostname === host; } catch (e) { return false; } };
  const { hiddenOrigins } = await api.storage.local.get('hiddenOrigins');
  if ((hiddenOrigins || []).includes(origin)) return false;
  if (s.mode === 'all') return true;
  if (s.mode === 'site') return !!s.siteOrigin && sameHost(s.siteOrigin);
  if (s.mode === 'list') return (s.sites || []).some(sameHost);
  return false;
}

async function rememberHidden(url, hidden) {
  let origin;
  try { origin = new URL(url).origin; } catch (e) { return; }
  const { hiddenOrigins } = await api.storage.local.get('hiddenOrigins');
  const set = new Set(hiddenOrigins || []);
  if (hidden) set.add(origin); else set.delete(origin);
  await api.storage.local.set({ hiddenOrigins: [...set] });
}

/* pending "open this fix" after navigation: tabId -> { url, selector } */
const pendingFlash = new Map();

api.tabs.onUpdated.addListener(async (tabId, info, tab) => {
  if (info.status !== 'complete' || !pendingFlash.has(tabId)) return;
  const p = pendingFlash.get(tabId);
  pendingFlash.delete(tabId);
  try {
    await inject(tabId);
    await sendToTab(tabId, { cmd: 'show' });
    setTimeout(() => sendToTab(tabId, { cmd: 'flash', selector: p.selector, rect: p.rect, area: p.area, scroll: p.scroll }), 600);
  } catch (e) { /* page not scriptable */ }
});
api.tabs.onRemoved.addListener((tabId) => pendingFlash.delete(tabId));

/* ---------------- events ---------------- */

// Shortcut: Ctrl+Alt+F. Chrome doesn't allow Ctrl+Alt in the manifest, so the manifest keeps
// Alt+Shift+F and Firefox is switched to Ctrl+Alt+F here (unless the person picked their own).
// On every browser the page itself also listens for Ctrl+Alt+F (see content.js).
async function setFirefoxShortcut() {
  if (!api.commands || typeof api.commands.update !== 'function') return;
  try {
    const cmds = await api.commands.getAll();
    const c = cmds.find((x) => x.name === 'toggle-bar');
    if (c && (!c.shortcut || c.shortcut === 'Alt+Shift+F')) await api.commands.update({ name: 'toggle-bar', shortcut: 'Ctrl+Alt+F' });
  } catch (e) { /* not supported */ }
}
api.runtime.onInstalled.addListener(() => { syncAutoScripts(); setFirefoxShortcut(); });
if (api.runtime.onStartup) api.runtime.onStartup.addListener(() => { syncAutoScripts(); setFirefoxShortcut(); pullShared().catch(() => {}); });
if (api.permissions.onAdded) api.permissions.onAdded.addListener(() => { syncAutoScripts(); });
if (api.permissions.onRemoved) api.permissions.onRemoved.addListener(() => { syncAutoScripts(); });

api.commands.onCommand.addListener(async (command, tab) => {
  if (command !== 'toggle-bar') return;
  let t = tab;
  if (!t || t.id === undefined) [t] = await api.tabs.query({ active: true, currentWindow: true });
  if (t) { try { await toggleBar(t.id); } catch (e) { /* restricted page */ } }
});

// The tab the person is looking at. Falls back for Firefox on Android, where the popup is its own tab.
async function activeWebTab() {
  const web = (t) => t && /^(https?|file):/.test(t.url || '');
  let [t] = await api.tabs.query({ active: true, currentWindow: true });
  if (web(t)) return t;
  const all = await api.tabs.query({ active: true });
  t = all.find(web);
  if (t) return t;
  const recent = (await api.tabs.query({})).filter(web).sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
  return recent[0] || null;
}

async function handle(msg, sender) {
  const tab = sender && sender.tab;
  switch (msg && msg.cmd) {
    case 'toggleActive': {
      const t = await activeWebTab();
      if (!t) return { ok: false, error: 'No tab' };
      try { const r = await toggleBar(t.id); return { ok: true, visible: r && r.visible }; }
      catch (e) { return { ok: false, error: String(e && e.message || e) }; }
    }
    case 'shouldAutoShow':
      return { show: await shouldAutoShow(msg.url) };
    case 'rememberHidden':
      await rememberHidden(msg.url, msg.hidden);
      return { ok: true };
    case 'activeTabUrl': {
      const t = await activeWebTab();
      return { url: t ? t.url : null };
    }
    case 'getSettings':
      return await getSettings();
    case 'setSettings': {
      const s = Object.assign(await getSettings(), msg.settings || {});
      await api.storage.local.set({ settings: s });
      await syncAutoScripts();
      return s;
    }
    case 'saveFix': {
      const fix = msg.fix;
      fix.id = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
      fix.time = Date.now();
      fix.updated = fix.time;
      fix.device = await deviceId();
      let warning = null;
      let hasFull = false, hasCrop = false;
      try {
        const png = await api.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
        const shots = await makeShots(png, fix.rect, fix.viewport);
        await putShots(fix.id, shots);
        hasFull = !!shots.full; hasCrop = !!shots.crop;
      } catch (e) {
        warning = 'No screenshot (press the toolbar icon once on this tab to allow screenshots).';
        console.warn('Claude To Fix capture failed', e);
      }
      fix.hasFull = hasFull; fix.hasCrop = hasCrop;
      const fixes = await getFixes();
      fixes.push(fix);
      await setFixes(fixes);
      const { syncFull } = await api.storage.local.get('syncFull');
      if (syncFull) warning = (warning ? warning + ' ' : '') + 'Saved on this computer only: sync is full (Download File, then Clear All).';
      setTimeout(() => uploadPending(), 0);
      return { ok: true, number: fixes.length, count: fixes.length, warning };
    }
    case 'listFixes': {
      setTimeout(() => uploadPending(), 0);
      const c = await getCloud();
      return { fixes: await getFixes(), cloud: { b2: CTFCloud.b2Ready(c.b2), gh: CTFCloud.ghReady(c.gh) } };
    }
    case 'getThumb': {
      try {
        const f = (await getFixes()).find((x) => x.id === msg.id);
        const shots = f ? await getShotsAny(f) : await getShots(msg.id);
        const b = shots && (shots.crop || shots.full);
        return { url: b ? await blobToDataUrl(b) : null };
      } catch (e) { return { url: null }; }
    }
    case 'updateFix': {
      const fixes = await getFixes();
      const f = fixes.find((x) => x.id === msg.id);
      if (f) Object.assign(f, msg.changes || {}, { updated: Date.now() });
      await setFixes(fixes);
      return { ok: !!f };
    }
    case 'deleteFix': {
      const before = await getFixes();
      const fixes = before.filter((x) => x.id !== msg.id);
      await setFixes(fixes);
      deleteCloudPictures(before.filter((x) => x.id === msg.id));
      try { await delShots(msg.id); } catch (e) { /* ignore */ }
      return { ok: true, count: fixes.length };
    }
    case 'reorder': {
      const fixes = await getFixes();
      const byId = new Map(fixes.map((f) => [f.id, f]));
      const ordered = msg.ids.map((id) => byId.get(id)).filter(Boolean);
      fixes.forEach((f) => { if (!msg.ids.includes(f.id)) ordered.push(f); });
      await setFixes(ordered);
      return { ok: true };
    }
    case 'clearAll':
      deleteCloudPictures(await getFixes());
      await setFixes([]);
      try { await clearShots(); } catch (e) { /* ignore */ }
      return { ok: true };
    case 'getMarkdown': {
      const fixes = await getFixes();
      return { text: buildMarkdown(fixes, false) };
    }
    case 'download': {
      const fixes = await getFixes();
      if (!fixes.length) return { ok: false, error: 'The list is empty.' };
      const blob = await buildZip();
      const name = `claude-fixes-${stamp(new Date(), '-', '')}.zip`;
      try {
        await downloadBlob(blob, name);
        return { ok: true, name };
      } catch (e) {
        return { ok: false, name, dataUrl: await blobToDataUrl(blob), error: String(e && e.message || e) };
      }
    }
    case 'sendToClaude':
      try { return await sendToClaude(); }
      catch (e) { return { ok: false, error: String(e && e.message || e) }; }
    case 'getCloud': {
      const c = await getCloud();
      const { cloudError } = await api.storage.local.get('cloudError');
      // Never hand the secrets back to the page: only what the settings screen shows.
      return {
        b2: c.b2 ? { endpoint: c.b2.endpoint, bucket: c.b2.bucket, keyId: c.b2.keyId, hasKey: !!c.b2.appKey } : null,
        gh: c.gh ? { repo: c.gh.repo, hasKey: !!c.gh.token, login: c.gh.login || null, via: c.gh.via || 'token' } : null,
        b2From: c.b2 && c.b2.from || null,
        canLogin: !!GH_APP_CLIENT_ID,
        error: cloudError || null
      };
    }
    case 'setCloud': {
      if (!fromPopup(sender)) return { ok: false, error: 'not allowed' }; // settings only from the popup
      const c = await getCloud();
      const which = msg.which;
      if (msg.clear) {
        c[which] = null;
        await api.storage.local.set({ cloud: c });
        if (which === 'gh') await api.storage.local.remove('ghLogin');
        return { ok: true };
      }
      const next = Object.assign({}, c[which] || {}, msg.values || {});
      Object.keys(next).forEach((k) => { if (typeof next[k] === 'string') next[k] = next[k].trim(); });
      try {
        if (which === 'b2') await CTFCloud.b2Test(next);
        else if (which === 'gh') await CTFCloud.ghTest(next);
        else return { ok: false, error: 'unknown' };
      } catch (e) {
        return { ok: false, error: String(e && e.message || e) };
      }
      c[which] = next;
      if (which === 'b2') delete c.b2.from;
      await api.storage.local.set({ cloud: c, cloudError: null });
      if (which === 'b2') setTimeout(() => uploadPending(), 0);
      let shared = false;
      try { shared = which === 'b2' ? await pushShared() : (await pullShared() || await pushShared()); } catch (e) { shared = false; }
      return { ok: true, shared };
    }
    case 'ghLoginStart': {
      if (!fromPopup(sender)) return { ok: false, error: 'not allowed' };
      try { return await ghLoginStart(msg.repo); }
      catch (e) { return { ok: false, error: String(e && e.message || e) }; }
    }
    case 'ghLoginState': {
      const { ghLogin } = await api.storage.local.get('ghLogin');
      if (!ghLogin) return { status: null };
      const { status, userCode, uri, login, error, expires } = ghLogin;
      return { status, userCode, uri, login, error, expires };
    }
    case 'ghLoginCancel': {
      await api.storage.local.remove('ghLogin');
      return { ok: true };
    }
    case 'pullShared': {
      try { return { ok: true, found: await pullShared() }; }
      catch (e) { return { ok: false, error: String(e && e.message || e) }; }
    }
    case 'openFix': {
      const fixes = await getFixes();
      const f = fixes.find((x) => x.id === msg.id);
      if (!f || !tab) return { ok: false };
      pendingFlash.set(tab.id, { url: f.url, selector: f.element && f.element.selector, rect: f.rect, area: !!f.area, scroll: f.scroll });
      await api.tabs.update(tab.id, { url: f.url });
      return { ok: true };
    }
    default:
      return { ok: false, error: 'unknown command' };
  }
}

api.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  queue(() => handle(msg, sender)).then(sendResponse, (e) => sendResponse({ ok: false, error: String(e && e.message || e) }));
  return true;
});
